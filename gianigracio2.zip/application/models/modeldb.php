<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modeldb extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('date');
		date_default_timezone_set('Asia/Jakarta');
	}
	public function login(){
		$username = set_value('username');
		$password = set_value('password');
		$result = $this->db->where('username', $username)
						   ->where('password', md5($password))
						   ->limit(1)
						   ->get('useradmin');
		if($result->num_rows() > 0){
			return $result->row();
		}else{
			return array();
		}
	}
	public function useradmin()
	{
		$query = $this->db->get('useradmin');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return 0;
		}
	}
	public function adduseradmin($data)
	{
		$this->db->insert('useradmin', $data);
	}
	public function removeuser()
	{
		$delete = $this->input->post('msg');
		for ($i=0; $i < count($delete) ; $i++) 
		{ 
			$this->db->where('id', $delete[$i]);
			$this->db->delete('useradmin');
		}
	}
	public function edituseradmin($id)
	{
		$query = $this->db->where('id', $id)->get('useradmin');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return 0;
		}
	}
	public function updateuseradmin($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('useradmin', $data);
	}
	
	public function allproducts(){
		$result = $this->db->select('produk.*, sum(size.qty) as totalqty, size.price')
						   ->from('produk, size')
						   ->where('produk.barcode = size.barcode')
						   ->group_by('barcode')
						   ->order_by('tgl','desc')
						   ->get();
		if($result->num_rows() > 0){
			return $result->result();
		}else{
			return array();
		}
	}
	public function displayproducts(){
		$result = $this->db->select('produk.*, sum(size.qty) as totalqty, size.price')
						   ->from('produk, size')
						   ->where('status','Enabled')
						   ->where('produk.barcode = size.barcode')
						   ->limit(12)
						   ->group_by('barcode')
						   ->order_by('tgl','desc')
						   ->get();
		if($result->num_rows() > 0){
			return $result->result();
		}else{
			return array();
		}
	}
	public function featuredproducts(){
		$result = $this->db->select('produk.*, sum(size.qty) as totalqty, size.price')
						   ->from('produk, size')
						   ->where('status','Enabled')
						   ->where('featured','Yes')
						   ->where('produk.barcode = size.barcode')
						   ->group_by('barcode')
						   ->order_by('tgl','desc')
						   ->get();
		if($result->num_rows() > 0){
			return $result->result();
		}else{
			return array();
		}
	}
	public function reviews()
	{
		$query = $this->db->get('review');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return array();
		}
	}
	public function editrev($id)
	{
		$query = $this->db->where('id', $id)
						  ->get('review');
		return $query->result();		  
	}
	public function updaterev($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('review', $data);
	}
	public function allcategories(){
		$result = $this->db->get('kategori');
		if($result->num_rows() > 0){
			return $result->result();
		}else{
			return array();
		}
	}
	public function kat($x)
	{
		$result = $this->db->where('id', $x)
						   ->get('kategori');
		return $result->result();
	}
	public function kategori($x)
	{
		$res = $this->db->select('idkategori')
						->where('barcode', $x)
						->get('produk');
		if ($res->num_rows() > 0){
			return $res->row()->idkategori;
		}else{
			return 0;
		}
	}
	public function addcategory($data){
		$this->db->insert('kategori', $data);
	}
	public function deletecateg($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('kategori');
	}
	public function removechecked() 
	{
		$delete = $this->input->post('msg');
		for ($i=0; $i < count($delete) ; $i++) 
		{ 
			$this->db->where('id', $delete[$i]);
			$this->db->delete('kategori');
		}		
	}
	public function removecekreview() 
	{
		$delete = $this->input->post('del');
		for ($i=0; $i < count($delete) ; $i++) 
		{ 
			$this->db->where('id', $delete[$i]);
			$this->db->delete('review');
		}		
	}
	public function gambar($x)
	{
		$this->db->where('barcode', $x);
        $query = $this->db->get('image');
        if($query->num_rows() > 0){
			return $query;
		}else{
			return null;
		}                         
	}
	function hapusgambar($x)
	{
    	$this->db->where('barcode',$k);
		$this->db->delete('image');
	}
	public function deleteallimg()
	{
		$delete = $this->input->post('msg');
		for ($i=0; $i < count($delete) ; $i++) 
		{ 
			$this->db->where('barcode',$delete[$i]);
	     	$query = $this->db->get('image');
	     	$row = $query->row();
	     	unlink("./uploads/".$row->image);

			$this->db->where('barcode', $delete[$i]);
	     	$this->db->delete('image');
		}
	}
	public function deleteprod()
	{
		$delete = $this->input->post('msg');
		for ($i=0; $i < count($delete) ; $i++) 
		{ 
			$this->db->where('barcode', $delete[$i]);
			$query = $this->db->get('produk');
     		$p = $query->row();
     		unlink("./uploads/".$p->image);
     		$this->db->where('barcode', $delete[$i]);
			$this->db->delete('produk');
			
			$this->db->where('barcode', $delete[$i]);
			$this->db->delete('size');
		}
	}
	public function deleteproduct($id)
	{
		$this->db->where('barcode',$id);
     	$query = $this->db->get('produk');
     	$row = $query->row();

     	unlink("./uploads/".$row->image);
     	
		$this->db->where('barcode', $id);
     	$this->db->delete('produk');		
	}
	public function deleteimage($id)
	{
		$this->db->where('barcode',$id);
     	$query = $this->db->get('image');
     	$row = $query->row();

     	unlink("./uploads/".$row->image);

		$this->db->where('barcode', $id);
     	$this->db->delete('image');
	}
	public function deletesize($id)
	{
		$this->db->where('barcode', $id);
		$this->db->delete('size');
	}
	public function addreview($data)
	{
		$this->db->insert('review', $data);
	}
	public function showrev($barcode)
	{
		$query = $this->db->where('barcode', $barcode)
						  ->where('approved', 'Yes')
						  ->get('review');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return 0;
		}
	}
	public function saveproduct($data){
		$this->db->insert('produk',$data);
	}
	public function updateproduct($id, $data)
	{
		$this->db->where('idproduk', $id);
		$this->db->update('produk', $data);
	}
	public function ambilcode(){
		$result = $this->db->select('max(barcode)')
						   ->from('produk')
						   ->limit(1)
						   ->get();
		if ($result->num_rows() > 0){
			return $result->row()->barcode;
		}else{
			return 0;
		}
	}
	public function savesize($data2){		
		$this->db->insert_batch('size',$data2);
	}
	public function saveimg($data3){		
		$this->db->insert_batch('image',$data3);
	}
	
	public function result($barcode, $nama, $status, $price){
		$result = $this->db->select('produk.*, sum(size.qty) as totalqty, size.price')
						   ->from('produk, size')
						   ->like('produk.barcode', $barcode)
						   ->like('produk.nama', $nama)
						   ->like('size.price', $price)
						   ->where('produk.status', $status)
						   ->where('produk.barcode = size.barcode')
						   ->group_by('barcode')
						   ->get();
		return $result->result();
	}
 	public function editproduct($id){
		$result = $this->db->where('barcode', $id)
						   ->get('produk');
		return $result->result();
	}
	public function editsize($id){
		$result = $this->db->where('barcode', $id)
						   ->get('size');
		return $result->result();
	}
	public function editimg($id){
		$result = $this->db->where('barcode', $id)
						   ->get('image');
		return $result->result();
	}
	public function detail($barcode)
	{
		$result = $this->db->where('barcode', $barcode)
						   ->get('produk');
		return $result->result();	
	}
	public function detailimg($barcode)
	{
		$result = $this->db->where('barcode', $barcode)
						   ->order_by('id', 'desc')
						   ->get('image');
		return $result->result();
	}
	public function searchproduk($cari, $num, $offset)
	{
		$query = $this->db->like('barcode', $cari)
						 ->order_by('tgl','desc')
						 ->get('produk',$num, $offset);
		return $query->result();
	}
	public function productcategory($x, $num, $offset)
	{
		$result = $this->db->where('idkategori', $x)
						   ->order_by('tgl','desc')
						   ->get('produk', $num, $offset);
		return $result->result();
	}
	public function getproduct($code)
	{
		$result = $this->db->select('produk.*, sum(size.qty) as totalqty, size.price')
						   ->from('produk, size')
						   ->where('produk.barcode', $code)
						   ->where('produk.barcode = size.barcode')
						   ->group_by('barcode')
						   ->order_by('tgl','desc')
						   ->limit(1)
						   ->get();
		if($result->num_rows() > 0){
			return $result->row();
		}else{
			return result();
		}
		
	}
	public function getsize($code)
	{
		$result = $this->db->where('barcode', $code)
						   ->get('size');
		return $result->result();
	}
	public function setting()
	{
		$query = $this->db->limit(1)->get('privacypol');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}else{
			return array();
		}
	}
	public function updatesetting($id, $data)
	{
		$this->db->where('id',$id);
		$this->db->update('privacypol',$data);
	}
	public function kota()
	{
		$query = $this->db->order_by('nama', 'asc')->get('kotakab');
		return $query->result();
	}
	public function propinsi()
	{
		$query = $this->db->order_by('nama', 'asc')->get('provinsi');
		return $query->result();
	}
	public function createacc($data)
	{
		$this->db->insert('customer', $data);
	}
	public function checkuser()
	{
		$email = set_value('email');
		$password = set_value('password');
		$result = $this->db->where('email', $email)
						   ->where('password', $password)
						   ->limit(1)
						   ->get('customer');
		if($result->num_rows() > 0){
			return $result->row();
		}else{
			return array();
		}
	}
	public function get_order($user)
	{
		$result = $this->db->where('firstname',$user)
						   ->limit(1)
						   ->get('customer');
		if($result->num_rows() > 0){
			return $result->row();
		}else{
			return array();
		}
	}
	public function process($total)
	{
		$inv_id = $this->getkodeunik();
		$invoice = array(
				'id'		=>$inv_id,
				'date'		=> date('Y-m-d H:i:s'),
				'due_date'	=> date('Y-m-d H:i:s', mktime(date('H'),date('i'),date('s'),date('m'),date('d') + 1,date('Y'))),
				'user_id'	=> $this->getloguserid(),
				'total'		=> $total,
				'status'	=> 'Uncompleted'
				);	
		$this->db->insert('invoices', $invoice);
//		$inv_id = $this->db->insert_id();
		$inv_id = $this->getkodeunik();
		foreach($this->cart->contents() as $item){
			$data = array(
				'invoice_id' 	=>$inv_id,
				'barcode'	 	=>$item['barcode'],
				'product_name' 	=>$item['name'],
				'size'		 	=>$item['size'],
				'qty' 			=>$item['qty'],
				'price' 		=>$item['price'],
				'image' 		=>$item['image'],
				);
			$this->db->insert('orders', $data); 
		}
		return TRUE;
	}
	function getkodeunik() { 
        $q = $this->db->query("SELECT MAX(right(invoice_id, 4)) AS idmax FROM orders");
        $x = $q->num_rows();
        $kd = ""; //kode awal
        if($x > 0){ //jika data ada
            foreach($q->result() as $k){
                $tmp = ((int)$k->idmax)+1; //string kode diset ke integer dan ditambahkan 1 dari kode terakhir
                $kd = sprintf("%04s", $tmp); //kode ambil 4 karakter terakhir
            }
            
        }else{ //jika data kosong diset ke kode awal
            $kd = "0001";
        }
       
        $kar = "INV"; //karakter depan kodenya
        //gabungkan string dengan kode yang telah dibuat tadi
        return $kar.$kd;
   } 
   
	public function getloguserid()
	{
		$result = $this->db->select('id')
						   ->where('email',$this->session->userdata('email'))
						   ->limit(1)
						   ->get('customer');
		if($result->num_rows() > 0){
			return $result->row()->id;
		}else{
			return 0;
		}
	}
	public function getcus($id)
	{
		$x = $this->db->where('id', $id)->get('customer');
			if($x->num_rows() > 0){
				return $x->result();
			}else{
				return 0;
			}
	}
	public function checkcus($name)
	{
		$query = $this->db->select('firstname')->where('email', $name)->get('customer');
		if($query->num_rows() > 0){
				return $query->row()->firstname;
			}else{
				return FALSE;
			}		
	}
	public function get_shop_history($user)
	{
		$result = $this->db->select('i.*, sum(o.qty * o.price) as total')
						   ->from('invoices i, customer t, orders o')
						   ->where('t.email', $user)
						   ->where('t.id = i.user_id')
						   ->where('o.invoice_id = i.id')
						   ->group_by('o.invoice_id')
						   ->get();
		if($result->num_rows() > 0){
			return $result->result();
		}else{
			return FALSE;
		}
	}
	public function getinvid($inv_id)
	{
		$result = $this->db->where('id', $inv_id)
						   ->get('invoices');
		if($result->num_rows() > 0){
			return $result->result();
		}else{
			return array();
		}
	}
	public function detailorder($inv_id)
	{
		$result = $this->db->where('invoice_id', $inv_id)->get('orders');
		if ($result->num_rows() > 0){
			return $result->result();
		}else{
			return array();
		}
	}
	public function cancelorder($id)
	{
		$data = array('status'=>'Canceled');
		$this->db->where('id',$id)->update('invoices', $data);
	}
	public function markinvconf($inv_id, $amount)
	{
		$ret = TRUE;		
		$result = $this->db->where('id', $inv_id)
						   ->limit(1)
						   ->get('invoices');
		if($result->num_rows() == 0){
			$ret = $ret && FALSE;
		}else{
			$total = $this->db->select('total')
						  ->where('id',$inv_id) 
						  ->get('invoices');
			$tot = $total->row()->total;
			if($tot > $amount){
				$ret = $ret && FALSE;	
			}else{
				$config['upload_path'] = FCPATH . 'uploads/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['max_size']	= '1000';
				$config['max_width']  = '2000';
				$config['max_height']  = '2000';
				$this->load->library('upload');
				$this->upload->initialize($config);
				if ( ! $this->upload->do_upload('namafile')){
					//gagal
					$error = array('error' => $this->upload->display_errors());
		            print_r($error) ;
				}else{
					$dataimg = array('upload_data' => $this->upload->data());
					$img = $dataimg['upload_data']['file_name'];
					$data = array('status'=>'Confirmed', 'image'=>$img);
					$this->db->where('id',$inv_id)->update('invoices', $data);
				}
			}
		}
		return $ret;
		return $ret;
	}
	public function gettotal($invid)
	{
		$total = $this->db->select('total')
						  ->where('id',$invid) 
						  ->get('invoices');
		if($total->num_rows() > 0){
			return $total->row()->total;	
		}else{
			return 0;
		}
	}
	public function getinvoices()
	{
		$result = $this->db->get('invoices');
		if($result->num_rows() > 0){
			return $result->result();
		}else{
			return array();
		}
	}

	public function changeaddress($id, $data)
	{
		$this->db->where('id', $id)->update('customer', $data);
	}
	public function getslider()
	{
		$result = $this->db->get('slider');
		if($result->num_rows() > 0){
			return $result->result();
		}else{
			return FALSE;
		}
	}
	public function addbanner($data)
	{
		$this->db->insert('slider', $data);
	}
	public function editbanner($id)
	{
		$this->db->where('id',$id);
		return $this->db->get('slider')->result();
	}
	public function updatebanner($id, $data)
	{
		$this->db->where('id',$id);
		$this->db->update('slider', $data);
	}
	public function deletebanner()
	{
		$delete = $this->input->post('msg');
		for ($i=0; $i < count($delete) ; $i++) 
		{ 
			$this->db->where('id',$delete[$i]);
	     	$query = $this->db->get('slider');
	     	$row = $query->row();
	     	unlink("./uploads/".$row->image);

			$this->db->where('id', $delete[$i]);
			$this->db->delete('slider');
		}	
	}
	public function gettotalsales()
	{
		$query = $this->db->select('sum(total) as totalsales')
						  ->where('status','Completed')
						  ->get('invoices');
		if($query->num_rows() > 0){
			return $query->row()->totalsales;
		}else{
			return FALSE;
		}
						  
	}
	public function testimoni()
	{
		$query = $this->db->get('testimonial');
		
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return array();
		}
	}
	public function testimonial()
	{
		$query = $this->db->where('status', 'Enabled')
						  ->get('testimonial');		
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return array();
		}
	}
	public function addtesti($data)
	{
		$this->db->insert('testimonial', $data);
	}
	public function hapustesti()
	{
		$delete = $this->input->post('msg');
		for ($i=0; $i < count($delete) ; $i++) 
		{ 
			$this->db->where('id', $delete[$i]);
			$this->db->delete('testimonial');
		}
	}
	public function edittesti($id)
	{
		$query = $this->db->where('id', $id)->get('testimonial');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return 0;
		}
	}
	public function updatetesti($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('testimonial', $data);
	}
}