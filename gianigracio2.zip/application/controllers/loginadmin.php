<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Loginadmin extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('modeldb');

	}
	function index(){
		$this->load->view('adminpage/loginview');
	}
	function auth(){
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');
		if($this->form_validation->run() == FALSE){
			$this->load->view('adminpage/loginview');
		}else{
			$this->load->model('modeldb');
			$valid = $this->modeldb->login();
			if ($valid == FALSE){
				$this->session->set_flashdata("pesan", "<div class=\"alert alert-danger\" id=\"alert\"><i class=\"glyphicon glyphicon-remove\"></i> Wrong Username or Password!</div>");
				redirect(base_url().'administrator');
			}else{
				//if match
				$this->session->set_userdata('username', $valid->username);	
				$this->session->set_userdata('group', $valid->group);	
				redirect(base_url().'admin');
			}
		}
	}
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url().'administrator');
	}
}