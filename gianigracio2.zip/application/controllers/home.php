<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('modeldb');
		$this->load->library('cart');
	}
	public function index()
	{
		$data['products'] = $this->modeldb->displayproducts();
		$data['featured'] = $this->modeldb->featuredproducts();
		$this->load->view('home', $data);
	}
	public function viewdata(){
		$data = $this->modeldb->allproducts();
		
		$arr = array();
		$i = 0;
		foreach($data as $r){
			$arr[$i]['barcode'] = $r->barcode;
			$arr[$i]['name'] = $r->nama;
			$arr[$i]['description'] = $r->deskripsi;
			$arr[$i]['image'] = $r->image;
			$arr[$i]['price'] = $r->price;
			$arr[$i]['qty'] = $r->totalqty;
			$i++;
		}
		echo json_encode($arr);
	}
	
	public function detail($barcode)
	{
		$x = $this->modeldb->kategori($barcode);
		$data['kategori'] = $this->modeldb->kat($x);		
		$data['img'] = $this->modeldb->detailimg($barcode);
		$data['prod'] = $this->modeldb->detail($barcode);
		$data['review'] = $this->modeldb->showrev($barcode);
		$this->load->view('detail2', $data);
	}
	public function categorylist($x, $offset=0)
	{
		$db = $this->db->where('idkategori', $x)
					   ->order_by('tgl','desc')
					   ->get('produk');
		$config['base_url'] = base_url().'home/categorylist/'.$x;
	   		
	   	$config['total_rows'] = $db->num_rows();
	   	$config['per_page'] = 6; /*Jumlah data yang dipanggil perhalaman*/ 
	   	$config['uri_segment'] = 4; /*data selanjutnya di parse diurisegmen 3*/
	   
	   /*Class bootstrap pagination yang digunakan*/
	   	$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
 
		$config['first_link'] = 'First';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		 
		$config['last_link'] = 'Last';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		 
		$config['next_link'] = '&raquo;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		 
		$config['prev_link'] = '&laquo;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		 
		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';
		 
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
	  
	   	$this->pagination->initialize($config);
	   
	   	$data['halaman'] = $this->pagination->create_links();
	   /*membuat variable halaman untuk dipanggil di view nantinya*/
		$data['offset'] = $offset;
		$dari = $this->uri->segment('4');
		
		$data['kategori'] = $this->modeldb->kat($x);
		$data['list'] = $this->modeldb->productcategory($x, $config['per_page'], $dari);
		$this->load->view('category-list', $data);
	}
	public function searchresult(){		
		$cari = $this->input->GET('search');
		$db = $this->db->like('barcode', $cari)->get('produk');
		$config['base_url'] = base_url().'search-result';
	   		
	   	$config['total_rows'] = $db->num_rows();
	   	$config['per_page'] = 6; /*Jumlah data yang dipanggil perhalaman*/ 
	   	$config['uri_segment'] = 4; /*data selanjutnya di parse diurisegmen 3*/
	   
	   /*Class bootstrap pagination yang digunakan*/
	   	$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
 
		$config['first_link'] = 'First';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		 
		$config['last_link'] = 'Last';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		 
		$config['next_link'] = '&raquo;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		 
		$config['prev_link'] = '&laquo;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		 
		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';
		 
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
	  
	   	$this->pagination->initialize($config);
	   
	   	$data['halaman'] = $this->pagination->create_links();
		$dari = $this->uri->segment('4');
		$cari = $this->input->get('search');
		$data['cari'] = $this->modeldb->searchproduk($cari, $config['per_page'], $dari);
//		var_dump($data);
		$this->load->view('searchresult', $data);
	}
	public function addtocart($code)
	{
		$product = $this->modeldb->getproduct($code);
		$idproduk = $product->idproduk;
		$barcode = $product->barcode;
		$name = $product->nama;
		$price = $product->price;
		$img = $product->image;
		$data = array(
			   'id'		=> $idproduk,
               'barcode'=> $barcode,
               'name'	=> $name,
               'qty'    => 1,
               'price'  => $price,
               'image'	=> $img
            );
		$this->cart->insert($data);
		redirect(base_url().'viewcart');
	}
	public function add_cart($code)
	{
		$product = $this->modeldb->getproduct($code);
		$idproduk = $product->idproduk;
		$barcode = $product->barcode;
		$name = $product->nama;
		$price = $product->price;
		$img = $product->image;
		$data = array(
			   'id'		=> $idproduk,
               'barcode'=> $barcode,
               'name'	=> $name,
               'size'	=> $_POST['size'],
               'qty'    => $_POST['quantity'],
               'price'  => $price,
               'image'	=> $img
            );
/*        var_dump($data);*/
		$this->cart->insert($data);
		redirect(base_url().'viewcart');
	}
	public function deleteitem($rowid)
	{
	    if ($rowid==="all"){
                       // Destroy data which store in  session.
			$this->cart->destroy();
		}else{
                    // Destroy selected rowid in session.
			$data = array(
				'rowid'   => $rowid,
				'qty'     => 0
			);
                     // Update cart data, after cancle.
			$this->cart->update($data);
		}
		
                 // This will show cancle data in cart.
		redirect(base_url());
	}
	public function updatecart()
	{
		$i = 1;
		foreach($this->cart->contents() as $items) {
			$data = array(
						'rowid'=>$items['rowid'],
						'qty'=>$_POST['qty'.$i]
						);
			$this->cart->update($data);
			$i++;
		}
		redirect(base_url().'home/viewcart');
	}
	public function viewcart()
	{
		$this->load->view('viewcart');
	}
	public function check($id)
	{
		$this->db->select('*');
        $this->db->from('size');
        $this->db->where('barcode',$id);
        $query = $this->db->get();
        $result = $query->array();
        
	}
	public function register()
	{
		$data['city'] = $this->modeldb->kota();
		$data['province'] = $this->modeldb->propinsi();
		$this->load->view('register', $data);
	}
	public function login()
	{
		$this->load->view('login');
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url().'home');
	}
	public function signin()
	{
		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('password','Password','required');
		if($this->form_validation->run() == TRUE){
			$valid = $this->modeldb->checkuser();
			if ($valid == FALSE){
				$this->session->set_flashdata("pesan", "<div class=\"alert alert-danger\" id=\"alert\"><i class=\"glyphicon glyphicon-remove\"></i> Wrong Email or Password!</div>");
				redirect(base_url(),'home/login');
			}else{
				//if match
				$this->session->set_userdata('email', $valid->email);	
				redirect(base_url().'home');
			}
		}
	}
	public function aboutus()
	{
		$data['about'] = $this->modeldb->setting();
		$data['testi'] = $this->modeldb->testimonial();
		$this->load->view('aboutus',$data);
	}
	public function contactus()
	{
		$data['contact'] = $this->modeldb->setting();
		$this->load->view('contactus', $data);
	}
	public function privacy()
	{
		$data['priv'] = $this->modeldb->setting();
		$this->load->view('privacy', $data);
	}
	public function terms()
	{
		$data['priv'] = $this->modeldb->setting();
		$this->load->view('terms', $data);
	}
	public function createaccount()
	{
		$this->form_validation->set_rules('fname','First Name','required');
		$this->form_validation->set_rules('lname','Last Name','required');
		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('phone','Phone Number','required');
		$this->form_validation->set_rules('fax','Fax');
		$this->form_validation->set_rules('company','Company');
		$this->form_validation->set_rules('address1','Address/1');
		$this->form_validation->set_rules('address2','Address/2');
		$this->form_validation->set_rules('city','City');
		$this->form_validation->set_rules('province','Province');
		$this->form_validation->set_rules('country','Country');
		$this->form_validation->set_rules('postal','Postal Code');
		$this->form_validation->set_rules('pass1','Password','required');
		$this->form_validation->set_rules('pass2','Re-Password','required|matches[pass1]');
		
		if($this->form_validation->run()== false){
			$data['city'] = $this->modeldb->kota();
			$data['province'] = $this->modeldb->propinsi();
			$this->load->view('register', $data);
		}else{
			$password = set_value('pass2');
			$data = array(
				'firstname' => $this->input->post('fname'),
				'lastname' => $this->input->post('lname'),
				'email' => $this->input->post('email'),
				'phone' => $this->input->post('phone'),
				'fax' => $this->input->post('fax'),
				'company' => $this->input->post('fax'),
				'address1' => $this->input->post('address1'),
				'address2' => $this->input->post('address2'),
				'city' => $this->input->post('city'),
				'province' => $this->input->post('province'),
				'country' => $this->input->post('country'),
				'postalcode' => $this->input->post('postal'),
				'password' => $password			
			);
			$this->modeldb->createacc($data);
			$this->session->set_flashdata("pesan", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Thank you for registering!</div>");
			redirect(base_url().'home/register');
		}
	}
	public function checkoutcomplete()
	{
		$this->load->view('complete');
	}
	public function addreview()
	{
		$date = date('d-m-Y H:i:s');
		$data = array(
			'tgl'		=> $date,
			'barcode'	=> $this->input->post('barcode'),
			'nama' 		=> $this->input->post('nama'),
			'isireview' => $this->input->post('review'),
			'rating' 	=> $this->input->post('rating'),
			'approved'	=> 'No'
		);
		$this->db->insert('review', $data);
		echo $html='<div class="alert alert-success" id="alert"><i class="fa fa-check"></i> Thank you for your review. It has been submitted and wait for approval!</div>';
		die;
	}
	public function sendemail()
	{
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$subject = $this->input->post('subject');
		$message = $this->input->post('message');
		
		/*$ci = get_instance();
        $ci->load->library('email');
        $config['protocol'] = "smtp";
        $config['smtp_host'] = "ssl://smtp.gmail.com";
        $config['smtp_port'] = "465";
        $config['smtp_user'] = "andry.chui@gmail.com";
        $config['smtp_pass'] = "firestorm";
        $config['charset'] = "utf-8";
        $config['mailtype'] = "html";
        $config['newline'] = "\r\n";
        
        
        $ci->email->initialize($config);
 
        $ci->email->from($email, $name);
        $list = array('giani.gracio@gmail.com');
        $ci->email->to($list);
        $ci->email->subject($subject);
        $ci->email->message($message);
        if ($this->email->send()) {
            $this->session->set_flashdata("sent", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Your Message has been Sent to the administrator!</div>");
            redirect(base_url().'contact');
        } else {
            show_error($this->email->print_debugger());
        }*/
		$this->email->to('giani.gracio@gmail.com');
		$this->email->from($email, $name);
		$this->email->subject($subject);
		$this->email->message($message);
		if($this->email->send()){
			$this->session->set_flashdata("sent", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Your Message has been Sent to the administrator!</div>");
		redirect(base_url().'contact');
   		}else{
		    show_error($this->email->print_debugger());
		}
	}
}
