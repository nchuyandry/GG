<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('email'))
		{
			$this->session->set_flashdata("pesan", "<div class=\"alert alert-danger\" id=\"alert\"><i class=\"fa fa-close\"></i> You Have to Log In First!</div>");
			redirect(base_url().'sign-in');
		}
		$this->load->model('modeldb');	
	}
	public function confirm($user)
	{
		$data['kota'] = $this->modeldb->kota();
		$data['prop'] = $this->modeldb->propinsi();
		$data['order'] = $this->modeldb->get_order($user);
		$this->load->view('orderreview', $data);
	}
	public function changeaddress()
	{
		$name = $this->session->userdata('email');
		$nama = $this->modeldb->checkcus($name);
		
			$data = array(
				'address1' => $this->input->post('address1'),
				'city' => $this->input->post('city'),
				'province' => $this->input->post('province'),
				'country' => $this->input->post('country'),
				'postalcode' => $this->input->post('postal')
			);
			$id = $this->input->post('iduser');
			$this->modeldb->changeaddress($id, $data);
			$this->session->set_flashdata("pesan", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Address Changed!</div>");
			$data['kota'] = $this->modeldb->kota();
			$data['prop'] = $this->modeldb->propinsi();
			$data['order'] = $this->modeldb->get_order($nama);
			$this->load->view('orderreview', $data);
		
	}
	public function process($total)
	{
		$process = $this->modeldb->process($total);
		if($process){
			$this->cart->destroy();
			redirect(base_url().'checkout-complete');
		}else{
			$this->session->set_flashdata("pesan", "<div class=\"alert alert-danger\" id=\"alert\"><i class=\"glyphicon glyphicon-remove\"></i> Failed to process your order, please try again!</div>");
			redirect(base_url().'viewcart');
		}
	}
	public function success()
	{
		$data['categ'] = $this->mcategory->all();
		$this->load->view('order_success',$data);
	}
	public function history()
	{
		$user = $this->session->userdata('email');
		$data['history'] = $this->modeldb->get_shop_history($user);
		$this->load->view('historyorder', $data);
	}
	public function orddetail($invid)
	{
		$data['invoice'] = $this->modeldb->getinvid($invid);
		$data['detord'] = $this->modeldb->detailorder($invid);
		$this->load->view('orderdetail', $data);
	}
	public function cancelord($id)
	{
		$this->modeldb->cancelorder($id);
		$this->session->set_flashdata("pesan", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Your Order has been Canceled!</div>");
		redirect(base_url().'history');
		
	}
	public function detailorder($invid)
	{
		$query = $this->db->where('invoice_id', $invid)->get('orders');
        $result = $query->result();
        $i = 0;
		foreach($result as $item){
			$i++;
			$tot = 0;
			$qty = $item->qty;
			$price = $item->price;
			$subtotal = $qty * $price;
			$tot += $subtotal;
			$disc = $tot * 0.25;
			$total = $tot - $disc;
			$img = base_url().'uploads/'.$item->image;
	        echo $html ='
	        			<tr>
	        			<td>'.$i.'</td>
	        			<td><img src="'.$img.'" width="80px"/></td>
	        			<td>'.$item->barcode.'</td>
	        			<td>'.$item->product_name.'</td>
	        			<td>'.$qty.' pcs</td>
	        			<td>Rp.'.number_format($price,0,',','.').',-</td>
	        			<td>Rp.'.number_format($subtotal,0,',','.').',-</td>
	        			</tr>';
    	} 
		die;
	}
	public function detailorder2($invid)
	{
		$query = $this->db->where('invoice_id', $invid)->get('orders');
        $result = $query->result();
        $i = 0;
		$tot = 0;
		foreach($result as $item){
			$i++;
			$qty = $item->qty;
			$price = $item->price;
			$subtotal = $qty * $price;
			$tot += $subtotal;
			$disc = $tot * 0.25;
			$total = $tot - $disc;
			
		}
		echo $html = '
				<tr>
					<td colspan="4"></td>
        			<td colspan="2"><strong>Subtotal</strong></td>
        			<td><b>Rp. '.number_format($tot,0,',','.').',-</b></td>
        		</tr>
				<tr>
					<td colspan="4"></td>
        			<td colspan="2"><strong>Disc -25%</strong></td>
        			<td><b>Rp. '.number_format($disc,0,',','.').',-</b></td>
        		</tr>
        		<tr>
        			<td colspan="4"></td>
        			<td colspan="2"><strong>Total</strong></td>
        			<td><b>Rp. '.number_format($total,0,',','.').',-</b></td>
        		</tr>';
		die;
	}
	public function payment()
	{
/*		$invid = $this->input->post('invoice_id');
		$amount = $this->input->post('amount');
		var_dump($this->modeldb->markinvconf($invid, $amount));*/
/*		$files = $_FILES['namafile'];
		print_r($files);
		*/
		/*$config['upload_path'] = FCPATH . 'uploads/';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']	= '1000';
			$config['max_width']  = '2000';
			$config['max_height']  = '2000';

			$this->load->library('upload');
			$this->upload->initialize($config); 
			if ( ! $this->upload->do_upload('namafile')){
					//gagal
				$error = array('error' => $this->upload->display_errors());
	            echo $error;
			}else{
					//berhasil
				$data = array('upload_data' => $this->upload->data());
				$img = $data['upload_data']['file_name'];
				var_dump($img);*/
				$isValid = $this->modeldb->markinvconf(set_value('invoice_id'), set_value('amount'));
				if($isValid == TRUE){
					$this->session->set_flashdata("pesan", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Thank you We Will Check for your payment!</div>");
					$user = $this->session->userdata('email');
					$data['history'] = $this->modeldb->get_shop_history($user);
					$this->load->view('historyorder', $data);
				}else{
					$this->session->set_flashdata("pesan", "<div class=\"alert alert-danger\" id=\"alert\"><i class=\"fa fa-check\"></i> Try Again Later!</div>");
					$user = $this->session->userdata('email');
					$data['history'] = $this->modeldb->get_shop_history($user);
					$this->load->view('historyorder', $data);
				}
		
	}
}