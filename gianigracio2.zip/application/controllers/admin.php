<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		date_default_timezone_set('Asia/Jakarta');
		$this->load->model('modeldb');
		$this->load->helper(array('url'));
		if($this->session->userdata('username')==FALSE){
			redirect(base_url().'administrator');
		}
	}	
	public function index(){
		$this->load->view('adminpage/homeview');
	}
	public function useradmin()
	{
		$data['useradmin'] = $this->modeldb->useradmin();
		$this->load->view('adminpage/useradmin', $data);
	}
	public function adduser()
	{
		$this->form_validation->set_rules('user','Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
		
		if($this->form_validation->run()==FALSE){
			$data['useradmin'] = $this->modeldb->useradmin();
			$this->load->view('adminpage/useradmin', $data);
		}else{	
			$data = array(
				'username'	=> $this->input->post('user'),
				'password'	=> md5( $this->input->post('password')),
				'group'	=> $this->input->post('group'),
			);
			$this->modeldb->adduseradmin($data);
			$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Added!</div>");
			redirect(base_url().'admin/useradmin');
		}
	}
	public function deleteuser()
	{
		$this->modeldb->removeuser();
		$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Deleted!</div>");
		redirect(base_url().'admin/useradmin');
	}
	public function edituser($id)
	{
		$data['edituser'] = $this->modeldb->edituseradmin($id);
		$data['useradmin'] = $this->modeldb->useradmin();
		$this->load->view('adminpage/edituseradmin', $data);
	}
	public function updateuser()
	{
		$this->form_validation->set_rules('user','Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
		
		if($this->form_validation->run()==FALSE){
			$data['edituser'] = $this->modeldb->edituseradmin($id);
			$data['useradmin'] = $this->modeldb->useradmin();
			$this->load->view('adminpage/edituseradmin', $data);
		}else{	
			$data = array(
				'username'	=> $this->input->post('user'),
				'password'	=> md5( $this->input->post('password')),
				'group'	=> $this->input->post('group'),
			);
			$id = $this->input->post('id');
			$this->modeldb->updateuseradmin($id, $data);
			$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Updated!</div>");
			redirect(base_url().'admin/useradmin');
		}
	}
	public function banner()
	{
		$data['slider'] = $this->modeldb->getslider();
		$this->load->view('adminpage/setbanner', $data);
	}
	public function addbanner()
	{
		$config['upload_path'] = FCPATH . 'uploads/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']	= '1000';
		$config['max_width']  = '2000';
		$config['max_height']  = '2000';
		$this->load->library('upload');
		$this->upload->initialize($config);
		if ( ! $this->upload->do_upload('slideimg')){
			//gagal
			$error = array('error' => $this->upload->display_errors());
		    print_r($error) ;
		}else{
			$dataimg = array('upload_data' => $this->upload->data());
			$img = $dataimg['upload_data']['file_name'];
			$data = array(
						'title'   => $this->input->post('title'),
						'description' => $this->input->post('deskripsi'),
						'image'	=> $img
						);
			$this->modeldb->addbanner($data);
			$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Slider Added!</div>");
			redirect(base_url().'admin/banner');	
		}
	}
	public function deletebanner()
	{
		$this->modeldb->deletebanner();
		redirect(base_url().'admin/banner');
	}
	public function editbanner($id)
	{
		$data['slider'] = $this->modeldb->getslider();
		$data['edit_banner'] = $this->modeldb->editbanner($id);
		$this->load->view('adminpage/editbanner',$data);
	}
	public function updatebanner()
	{
		$config['upload_path'] = FCPATH . 'uploads/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']	= '1000';
		$config['max_width']  = '2000';
		$config['max_height']  = '2000';
		$this->load->library('upload');
		$this->upload->initialize($config);
		if ( ! $this->upload->do_upload('slideimg')){
			//gagal
			$error = array('error' => $this->upload->display_errors());
		    print_r($error) ;
		}else{
			$dataimg = array('upload_data' => $this->upload->data());
			$img = $dataimg['upload_data']['file_name'];
			$data = array(
						'title'   => $this->input->post('title'),
						'description' => $this->input->post('deskripsi'),
						'image'	=> $img
						);
			$id = $this->input->post('id');
			$this->modeldb->updatebanner($id, $data);
			$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Slider Updated!</div>");
			redirect(base_url().'admin/banner');	
		}
	}
	public function setting(){
		$data['pri'] = $this->modeldb->setting();
		$this->load->view('adminpage/setting', $data);
	}
	public function updatesetting()
	{
		$this->form_validation->set_rules('nama','Website Name','required');
		$this->form_validation->set_rules('descrip','Description');
		$this->form_validation->set_rules('address','Address');
		$this->form_validation->set_rules('phone','Phone Number');
		$this->form_validation->set_rules('email','Email');
		$this->form_validation->set_rules('fb','Facebook');
		$this->form_validation->set_rules('twit','Twitter');
		$this->form_validation->set_rules('titlepriv','Title');
		$this->form_validation->set_rules('privacypol','Privacy Policy');
		
		if($this->form_validation->run()==FALSE){
			$data['pri'] = $this->modeldb->setting();
			$this->load->view('adminpage/setting',$data);
		}else{	
			$data = array(
					'webname' => $this->input->post('nama'),
					'descrip' => $this->input->post('descrip'),
					'address' => $this->input->post('address'),
					'phone' => $this->input->post('phone'),
					'email' => $this->input->post('email'),
					'fb' => $this->input->post('fb'),
					'twit' => $this->input->post('twit'),
					'terms' => $this->input->post('terms'),
					'titlepriv' => $this->input->post('title'),
					'privacypol' => $this->input->post('deskripsi')
					);
			$id = $this->input->post('idx');
			$this->modeldb->updatesetting($id, $data);
			$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"glyphicon glyphicon-ok\"></i> Data Category Added!</div>");
			redirect(base_url().'admin/setting');
		}
	}
	public function categories(){
		$data['allcategories'] = $this->modeldb->allcategories();
		$this->load->view('adminpage/category', $data);
	}
	public function deleteselected()
	{
		$this->modeldb->removechecked();
		redirect(base_url().'admin/categories');
	}
	public function deleteselreview()
	{
		$this->modeldb->removecekreview();
		redirect(base_url().'admin/reviews');
	}
	public function deletecategory($id)
	{
		$this->modeldb->deletecateg($id);
		$this->session->set_flashdata("pesan", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Category Deleted!</div>");
		redirect(base_url().'admin/categories');
	}
	public function addcategory(){
		$this->form_validation->set_rules('kategori','Category Name','required');
		if($this->form_validation->run()==FALSE){
			$data['allcategories'] = $this->modeldb->allcategories();
			$this->load->view('adminpage/category', $data);
		}else{
			$data = array(
				'namakat'   => $this->input->post('kategori'),
				'deskripsi' => $this->input->post('deskripsi')
				);
			$this->modeldb->addcategory($data);
			$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Added!</div>");
			redirect(base_url().'admin/categories');	
		}
	}
	public function products(){
		$data['allproducts'] = $this->modeldb->allproducts();
		$this->load->view('adminpage/products', $data);
	}
	
	public function addproduct(){
		$this->form_validation->set_rules('tgl','Date Input','required');
		$this->form_validation->set_rules('barcode','Barcode','required');
		$this->form_validation->set_rules('nama','Product Name','required');
/*		$this->form_validation->set_rules('qty','Quantity','required');
		$this->form_validation->set_rules('price','Price','required');*/
		if($this->form_validation->run()==FALSE){
			$data['kat'] = $this->modeldb->allcategories();
			$this->load->view('adminpage/addproduct', $data);
		}else{
    		$number_of_files = sizeof($_FILES['img']['tmp_name']);
    		$files = $_FILES['img'];
    		for($i=0;$i<$number_of_files;$i++)
    		{
      			if($_FILES['img']['error'][$i] != 0){
	        		$this->form_validation->set_message('fileupload_check', 'Ada error ga bisa upload');
	        		return FALSE;
      			}
    		}
    		$this->load->library('upload');
    		$config['upload_path'] = FCPATH . 'uploads/';
    		$config['allowed_types'] = 'gif|jpg|png';
    		for ($i = 0; $i < $number_of_files; $i++)
    		{
				$_FILES['img']['name'] = $files['name'][$i];
				$_FILES['img']['type'] = $files['type'][$i];
			 	$_FILES['img']['tmp_name'] = $files['tmp_name'][$i];
			 	$_FILES['img']['error'] = $files['error'][$i];
			  	$_FILES['img']['size'] = $files['size'][$i];
      			$this->upload->initialize($config);
		      	$this->upload->do_upload('img');
				$this->_uploaded[$i] = $this->upload->data();
		      	
    		}
			
			
			$data = array(
				'tgl' 			=> $this->input->post('tgl'),
				'barcode'		=> $this->input->post('barcode'),
				'nama' 			=> $this->input->post('nama'),
				'deskripsi' 	=> $this->input->post('deskripsi'),
				'tag' 			=> $this->input->post('tagsinput'),
				'idkategori' 	=> $this->input->post('kategori'),
				'model' 		=> $this->input->post('model'),
				'status' 		=> $this->input->post('status'),
				'featured' 		=> $this->input->post('featured'),
				'image' 		=> $files['name']['0']
					);

 			$data2 = array();
        	foreach($_POST['size'] AS $key => $val){
            	$data2[] = array(
	                "barcode" 	=> $_POST['barcode'],
	                "size" 		=> $_POST['size'][$key],
	                "qty"       => $_POST['qty'][$key],
	                "price"     => $_POST['price'][$key]
            	);
        	}          
    
			$data3 = array();
			foreach($files['name'] as $a => $b){
				$data3[] = array(
					'barcode'	=>$this->input->post('barcode'),
					'image'		=>$files['name'][$a]
					);
			}

			$this->modeldb->saveproduct($data);
			$this->modeldb->savesize($data2);
			$this->modeldb->saveimg($data3);
			$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Added!</div>");
			redirect(base_url().'admin/products');
		}
		
	}
	public function editproduct($id){
		$data['kat'] = $this->modeldb->allcategories();
		$data['editp'] = $this->modeldb->editproduct($id);
		$data['edits'] = $this->modeldb->editsize($id);
		$data['editimg'] = $this->modeldb->editimg($id);
/*		var_dump('<pre>');
		var_dump($this->modeldb->editproduct($id));
		var_dump('</pre>');*/
		$this->load->view('adminpage/editproduct', $data);
		
	}
	public function updateimg()
	{
		$number_of_files = sizeof($_FILES['img']['tmp_name']);
    	$files = $_FILES['img'];
    	for($i=0;$i<$number_of_files;$i++)
    	{
      		if($_FILES['img']['error'][$i] != 0){
	        	$this->form_validation->set_message('fileupload_check', 'Ada error ga bisa upload');
	        	return FALSE;
      		}
    	}
    	$this->load->library('upload');
    	$config['upload_path'] = FCPATH . 'uploads/';
    	$config['allowed_types'] = 'gif|jpg|png';
    	for ($i = 0; $i < $number_of_files; $i++)
    	{
			$_FILES['img']['name'] = $files['name'][$i];
			$_FILES['img']['type'] = $files['type'][$i];
			$_FILES['img']['tmp_name'] = $files['tmp_name'][$i];
			$_FILES['img']['error'] = $files['error'][$i];
			$_FILES['img']['size'] = $files['size'][$i];
      		$this->upload->initialize($config);
		    $this->upload->do_upload('img');
			$this->_uploaded[$i] = $this->upload->data();
		}
		$data3 = array();
		foreach($files['name'] as $a => $b){
			$data3[] = array(
					'barcode'	=>$this->input->post('barcode'),
					'image'		=>$files['name'][$a]
					);
		}
		$id = $this->input->post('barcode');
		$this->modeldb->saveimg($data3);
		redirect(base_url().'admin/editproduct/'.$id);
	}
	public function updateproduct()
	{
		
		$data = array(
				'tgl' 			=> $this->input->post('tgl'),
				'nama' 			=> $this->input->post('nama'),
				'deskripsi' 	=> $this->input->post('deskripsi'),
				'tag' 			=> $this->input->post('tagsinput'),
				'idkategori' 	=> $this->input->post('kategori'),
				'model' 		=> $this->input->post('model'),
				'status' 		=> $this->input->post('status'),
				'featured' 		=> $this->input->post('featured')
					);
        foreach($_POST['size'] AS $key => $val){
            $data2[] = array(
            		"barcode"	=> $_POST['barcode'],
	                "size" 		=> $_POST['size'][$key],
	                "qty"       => $_POST['qty'][$key],
	                "price"     => $_POST['price'][$key]
            	);
        }          
    	$id = $this->input->post('id');
		$this->modeldb->updateproduct($id, $data);			
		$this->modeldb->savesize($data2);
		$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Updated!</div>");
		redirect(base_url().'admin/products');
	}
	public function hapusgambar()
	{
		$this->modeldb->deleteallimg();
	}
	public function deleteselprod()
	{
		$this->modeldb->deleteprod();
		$this->modeldb->deleteallimg();
		$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Deleted!</div>");
		redirect(base_url().'admin/products');
	}
	public function deleteproduct($id)
	{
		$this->modeldb->deleteproduct($id);
		$this->modeldb->deleteimage($id);
		$this->modeldb->deletesize($id);
		$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Deleted!</div>");
		redirect(base_url().'admin/products');
	}
	public function result(){
		$barcode = $this->input->get('barcode');
		$nama = $this->input->get('nama');
		$status = $this->input->get('status');
		$qty = $this->input->get('qty');
		$price = $this->input->get('price');
		$data['allproducts'] = $this->modeldb->result($barcode,$nama, $status, $price);
		$this->load->view('adminpage/products', $data);
	}
	public function Deletesize($id)
	{
		$this->db->where('idsize',$id);
        $this->db->delete('size');
        die;
	}
	public function Deleteimg($id)
	{
		$this->db->where('id',$id);
        $this->db->delete('image');
        die;
	}
	
	public function EditSize($id)
    {    
            $this->db->select('*');
            $this->db->from('size');
            $this->db->where('idsize',$id);
            $query = $this->db->get();
            $result = $query->result();
            //print_r($result );die;
            echo $html = '
            <td class="size'.$id.'">
            <form method="POST" role="form" id="frmsize'.$result[0]->idsize.'">     
            <input type="text" name="size" class="form-control" value="'.$result[0]->size.'">
            <input type="text" name="qty" class="form-control" value="'.$result[0]->qty.'">
            <input type="text" name="price" class="form-control" value="'.$result[0]->price.'">               
            <input type="button" value="Update" onclick="UpdateSize('.$result[0]->idsize.')" class="form-submit btn-xs" />                  
            <a href=""   title="Cancel" onclick="cancel()" >Cancel</a>
            <a href="javascript:void(0)" class="hide" id="hide'.$result[0]->idsize.'">Please wait...</a>           
			</form>
    		</td>
            
            <hr/>';
        	die;
    }
    public function UpdateSize($id)
            {  
                    $data = array(
	                    'size' => $this->input->post('size'),
	                    'qty' =>$this->input->post('qty'),
	                    'price'=>$this->input->post('price')
                    );
                    //echo "<pre>";
                    //print_r($data);die;
                    var_dump($id);
                    $this->db->where('idsize', $id);
                    $this->db->update('size', $data);
                    $this->db->select('*');
                    $this->db->where('idsize', $id);
                    $this->db->from('size');
                    $query = $this->db->get();
                    $result = $query->result();
                    //print_r($result );
                    //echo $result[0]->id;die;
                    echo $html ="
                    <tr id='size".$id."'>
		            	<td>#</td>
		                <td>".$result[0]->size."</td>
		            	<td>".$result[0]->qty."</td>
		           		<td>".$result[0]->price."</td>
		                <td>
		                	<a href='javascript:void(0)' onclick='EditSize(".$id.")' class='btn btn-warning btn-sm btn-xs' title='Edit Size' ><i class='fa fa-pencil-square-o'></i></a>
		                	<a href='javascript:void(0)' onclick='DeleteSize(".$id.")'  title='Delete Size' class='btn btn-sm btn-xs btn-danger'><i class='fa fa-trash'></i></a>
		            	</td>
		        	</tr>" ;    
        }
	public function invoices()
	{
		$data['inv'] = $this->modeldb->getinvoices();
		$this->load->view('adminpage/invoices', $data);
	}	
	public function detailinv($invid)
	{
		$data['invoices'] = $this->modeldb->getinvid($invid);
		$data['orders'] = $this->modeldb->detailorder($invid);
		$this->load->view('adminpage/detailorders', $data);
	}
	public function updatestatus()
	{
		$invid = $this->input->post('invid');
		$stat = $this->input->post('status');
		$this->db->where('id',$invid)->update('invoices', array('status'=>$stat));
		$data['inv'] = $this->modeldb->getinvoices();
		$this->load->view('adminpage/invoices', $data);
	}
	public function reviews()
	{
		$data['reviews'] = $this->modeldb->reviews();
		$this->load->view('adminpage/reviews', $data);
	}
	public function editreview($id)
	{
		$data['editrev'] = $this->modeldb->editrev($id);
		$this->load->view('adminpage/editreview', $data);
	}
	public function updaterev()
	{
		$data = array(
			'barcode'	=> $this->input->post('barcode'),
			'nama'		=> $this->input->post('author'),
			'isireview'	=> $this->input->post('review'),
			'rating'	=> $this->input->post('rating'),
			'approved'	=> $this->input->post('approved')
		);
		$id = $this->input->post('id');
		$this->modeldb->updaterev($id, $data);
		$this->session->set_flashdata("pesan", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Updated!</div>");
		redirect(base_url().'admin/reviews');
	}
	
	public function testimonial()
	{
		$data['testimonial'] = $this->modeldb->testimoni();
		$this->load->view('adminpage/testimonial', $data);
	}
	public function addtesti()
	{
		$this->form_validation->set_rules('cusname','Customer Name', 'required');
		$this->form_validation->set_rules('job','Job Position', 'required');
        $this->form_validation->set_rules('content', 'Content', 'required');
		$this->form_validation->set_rules('status', 'Status', 'required');
		
		if($this->form_validation->run()==FALSE){
			$data['testimonial'] = $this->modeldb->testimoni();
			$this->load->view('adminpage/testimonial', $data);
		}else{	
			$data = array(
				'namakustomer'	=> $this->input->post('cusname'),
				'pekerjaan'		=> $this->input->post('job'),
				'konten'		=> $this->input->post('content'),
				'status'		=> $this->input->post('status')
			);
			$this->modeldb->addtesti($data);
			$this->session->set_flashdata("sukses", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Added!</div>");
			redirect(base_url().'admin/testimonial');
		}
		
	}
	public function deltes()
	{
		$this->modeldb->hapustesti();
		redirect(base_url().'admin/testimonial');
	}
	public function edittesti($id)
	{
		$data['edites'] = $this->modeldb->edittesti($id);	
		$data['testimonial'] = $this->modeldb->testimoni();	
		$this->load->view('adminpage/edittestimoni', $data);
		
	}
	public function updatetesti()
	{
		$data = array(
			'namakustomer'	=> $this->input->post('cusname'),
			'pekerjaan'		=> $this->input->post('job'),
			'konten'		=> $this->input->post('content'),
			'status'		=> $this->input->post('status')
		);
		$id = $this->input->post('id');
		$this->modeldb->updatetesti($id, $data);
		$this->session->set_flashdata("pesan", "<div class=\"alert alert-success\" id=\"alert\"><i class=\"fa fa-check\"></i> Data Updated!</div>");
		redirect(base_url().'admin/testimonial');
	}
}
