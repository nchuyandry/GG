
<html ng-app="bigmoney" >
  <head>

	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.8/angular.min.js" ></script>
    <!-- SITE TITTLE -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BIG MONEY Store - Online Shop</title>
    
    <!-- PLUGINS CSS STYLE -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/animate.css">
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">

    <!-- GOOGLE FONT -->    
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    
    <!-- CUSTOM CSS -->
    <link href="<?=base_url()?>assets/css/homestyle.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>

<body>
<div class="main-wrapper" ng-controller="kontrol">
	<?php $this->load->view('topbar')?>
	<?php $this->load->view('navbar')?>
    <?php $this->load->view('carousel')?>
   <!-- <a href="<?=base_url().'home/viewdata'?>">show</a>-->
<!--mainfeature-->
<section class="content" >
<div class="container anim" >
	<div class="row featuredCollection wow"> 
		<div class="col-xs-12">
			<div class="page-header">
				<h4>Featured Collection</h4>
			</div>
		</div>
		<?php 
			foreach($products as $row){
		?>
		
		<div class="col-sm-4 col-xs-12" ><!-- ng-repeat="product in products" -->
			<div class="" >
				<img src="<?=base_url().'uploads/'.$row->image?>" alt="feature-collection-image" width="200px" >
             		<div class="masking">
             			<a href="<?=base_url().'home/detail/'.$row->barcode?>" class="btn viewBtn">View Products</a>
             		</div>
                <div class="caption">
                  <h4><?=$row->nama?></h4>
                </div>
			</div>
		</div>
		<?php } ?>
	</div>
	<div class="row featuredProducts wow" >
    	<div class="col-md-12">
			<div class="page-header">
                <h4>Featured Products</h4>
           	</div>
      	</div>
        <div ng-repeat="product in products" class="col-sm-3 col-xs-12">
			<div class="slide">
              		<div class="productImage clearfix">
                    	<img ng-src="<?=base_url().'uploads/'?>{{product.image}}" alt="featured-product-img">
                    	<div class="productMasking">
                      		<ul class="list-inline btn-group" role="group">
                        		<li>
                        			<a data-toggle="modal" href=".login-modal" class="btn btn-default"><i class="fa fa-heart"></i></a>
                        		</li>
                        		<li>
                        			<a href="cart-page.html" class="btn btn-default"><i class="fa fa-shopping-cart"></i></a>
                        		</li>
                        		<li>
                        			<a data-toggle="modal" href=".quick-view" class="btn btn-default"><i class="fa fa-eye"></i></a>
                        		</li>
                      		</ul>
                    	</div>
                  	</div>
                  	<div class="productCaption clearfix">
						<a href="single-product.html">
                      		<h5>{{product.name}}</h5>
                    	</a>
                    	<h3>{{product.price | currency}}</h3>
                  	</div>
            	</div>                
       	</div>
	</div>
	<div class="row featuredProducts wow">
       	
       	<div class="col-sm-3  col-xs-12">
        	<div class="slide">
                  <div class="productImage">
                    <img src="img/home/featured-product/product-05.jpg" alt="featured-product-img">
                    <div class="productMasking">
                      <ul class="list-inline btn-group" role="group">
                        <li><a data-toggle="modal" href=".login-modal" class="btn btn-default"><i class="fa fa-heart"></i></a></li>
                        <li><a href="cart-page.html" class="btn btn-default"><i class="fa fa-shopping-cart"></i></a></li>
                        <li><a data-toggle="modal" href=".quick-view" class="btn btn-default"><i class="fa fa-eye"></i></a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="productCaption">
                    <a href="single-product.html">
                      <h5>Mauris lobortis augue</h5>
                    </a>
                    <h3>$199</h3>
                  </div>
                </div>
		</div>
	</div>
</div>
</section>
      <?php $this->load->view('footer')?>
</div>
</div>
<!-- LOGIN MODAL -->
    <div class="modal fade login-modal" id="login" tabindex="-1" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3 class="modal-title">Log In</h3>
          </div>
          <div class="modal-body">
            <form action="#" method="POST" role="form">
              <div class="form-group">
                <label for="">Enter Email</label>
                <input type="email" class="form-control" id="email" name="email">
              </div>
              <div class="form-group">
                <label for="">Password</label>
                <input type="password" class="form-control" id="password" name="password">
              </div>
              <div class="checkbox">
                <label>
                  <input type="checkbox"> Remember Me
                </label>
              </div>
              <button type="submit" class="btn btn-sign btn-block">log in</button>
              <button type="button" class="btn btn-link btn-block">Forgot Password?</button>
            </form>  
          </div>
        </div>
      </div>
    </div>

    <!-- SIGN UP MODAL -->
    <div class="modal fade" id="signup" tabindex="-1" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3 class="modal-title">Create an account</h3>
          </div>
          <div class="modal-body">
            <form action="" method="POST" role="form">
              <div class="form-group">
                <label for="">Enter Email</label>
                <input type="email" class="form-control" id="">
              </div>
              <div class="form-group">
                <label for="">Password</label>
                <input type="password" class="form-control" id="">
              </div>
              <div class="form-group">
                <label for="">Confirm Password</label>
                <input type="password" class="form-control" id="">
              </div>
              <button type="submit" class="btn btn-sign btn-block">Sign up</button>
            </form>  
          </div>
        </div>
      </div>
    </div>

	<script src="<?=base_url()?>assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/wow.min.js" type="text/javascript"></script>
	<script>
		var app=angular.module('bigmoney',[]);
		app.controller('kontrol',function($scope,$http){
    		$scope.products=[];
    		$http.get("<?php echo base_url('home/viewdata');?>").success(function(result){
     		$scope.products=result;
    	});
    
   		});
	</script>
	<script>
    	new WOW().init();
    	$(window).scroll(function(){
    		if($(this).scrollTop()>20){
				$(".featuredCollection").addClass('fadeInDown');
			}
    	});
    	$(window).scroll(function(){
    		if($(this).scrollTop()>20){
				$(".featuredProducts").addClass('fadeInDown');
			}
    	});
    </script>
</body>
</html>