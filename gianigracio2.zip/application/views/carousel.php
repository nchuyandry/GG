<div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
	<ol class="carousel-indicators">
		<?php $db = $this->db->get('slider');$x = $db->num_rows();for($i = 0; $i < $x; $i++){?>
		<li data-target="#myCarousel" data-slide-to="<?=$i?>" class="active"></li>
		<?php } ?>
	</ol>
	<div class="carousel-inner" role="listbox">
<?php $i=0;$this->load->model('modeldb');$x = $this->modeldb->getslider();foreach($x as $row){$i++;?>     
		<div class="item <?php if($i==1){echo'active';}?>">
			<img class="slide" src="<?=base_url()?>assets/img/slider-bg.jpg" >
          	<div class="carousel-caption">
            	<img class="img-responsive animated bounceInDown" src="<?=base_url().'uploads/'.$row->image?>"/>
              	<h1 class="animated bounceInLeft "><?=$row->title?></h1>
              	<p class="animated bounceInRight"><?=$row->description?></p>
              	<a class="btn btn-slider animated zoomInUp" href="javascript:void(0)" role="button" onclick="buyNow()">Shop Now <i class="fa fa-chevron-right"></i></a>
            </div>
        </div>
<?php } ?>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>

    </div>
</div>