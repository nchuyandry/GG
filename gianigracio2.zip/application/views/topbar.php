<div class="topBar">
		<div class="container">
			<div class="row">
           		<div class="col-md-6 hidden-sm hidden-xs">
	                <ul class="list-inline wow fadeInDown">
	                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
	                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
	                  <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
	                  <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
	                  <li><a href="#"><i class="fa fa-tumblr"></i></a></li>
	                </ul>
              	</div>
              	<div class="col-md-6 col-xs-12">
                	<ul class="list-inline pull-right  wow fadeInDown">
                  	<li>
                  		<a data-toggle="modal" href='.login-modal'>Log in</a>
                  		<small>  or  </small>
                  		<a data-toggle="modal" href='#signup'>&nbsp;Create an account</a>
                  	</li>
                  	<li class="dropdown searchBox">
	                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-search"></i></a>
	                    <ul class="dropdown-menu dropdown-menu-right">
                    		<li>
                        		<span class="input-group">
                          		<input type="text" class="form-control" placeholder="Search�" aria-describedby="basic-addon2">
                          		<span class="input-group-addon" id="basic-addon2">Search</span>
                        		</span>
                      		</li>
                    	</ul>
                  	</li>
                  	<li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-shopping-cart"></i> Rp. <?=$this->cart->total_items()?></a>
                    <ul class="dropdown-menu dropdown-menu-right">
                      <li>Item(s) in your cart</li>
                      <li>
                        <!--<a href="single-product.html">
                          <div class="media">
                            <img class="media-left media-object" src="img/home/cart-items/cart-item-01.jpg" alt="cart-Image">
                            <div class="media-body">
                              <h5 class="media-heading">INCIDIDUNT UT <br><span>2 X $199</span></h5>
                            </div>
                          </div>
                        </a>-->
                      </li>                      
                      <li>
                        <div class="btn-group" role="group" aria-label="...">
                          <button type="button" class="btn btn-default" onclick="location.href='cart-page.html';">Shopping Cart</button>
                          <button type="button" class="btn btn-default" onclick="location.href='checkout-step-1.html';">Checkout</button>
                        </div>
                      </li>
                    </ul>
                  	</li>
                	</ul>
              	</div>
            </div>
          </div>    
        </div>