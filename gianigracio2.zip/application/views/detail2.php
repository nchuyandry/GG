
<!doctype html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
	<![endif]-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php foreach($prod as $m){?>
	<meta name="description" content="">
	<meta name="author" content="Giani Gracio">
	<meta name="keywords" content="<?=$m->tag?>">
	<?php } ?>
	<title>Giani Gracio | Online Shop</title>
	
	<!-- Bootstrap Core CSS -->
	<link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Google Web Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css">
	
	<!-- CSS Files -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/stylecss.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/responsive.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">
	
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="https://cdn.rawgit.com/igorlino/elevatezoom-plus/1.1.17/src/jquery.ez-plus.js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/js/bootstrap.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/ie8-responsive-file-warning.js"></script>
	<![endif]-->
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
.well {
    border: 0;
    border-radius: 0;
    background: #fff;
    -webkit-box-shadow: none;
    box-shadow: none;
}
.well .media{
	padding-left: 0;
}
.well .media-left{
	width: 1200px;
	text-align: center;
	padding-right: 20px;
}
	</style>
	<!-- Fav and touch icons -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/fav-144.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/fav-114.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/fav-72.png">
	<link rel="apple-touch-icon-precomposed" href="images/fav-57.png">
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">

</head>
<body>
<?php $this->load->view('topheader')?>
<?php
	$this->load->model('modeldb');
	$data['kategori'] = $this->modeldb->allcategories(); 
	$this->load->view('navbar2', $data);
?>
<!-- Main Container Starts -->
	<div class="main-container container">
		<?php foreach($prod as $rows){ ?>

		<!-- Primary Content Starts -->
			<!-- Breadcrumb Starts -->
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<?php foreach($kategori as $kat){?>
					<li><a href="<?=base_URL().'home/categorylist/'.$rows->idkategori?>"><?=$kat->namakat?></a></li>
					<?php } ?>
					<li class="active"><?=$rows->barcode?></li>
				</ol>
			<!-- Breadcrumb Ends -->
			<!-- Product Info Starts -->
				<div class="row product-info full">
				<!-- Left Starts -->
					<div class="col-sm-4 images-block">
						<div id="carousel" class="carousel slide" >
                    		<div class="carousel-inner">
<?php $i=0;$this->load->model('modeldb');$g = $this->modeldb->detailimg($rows->barcode);foreach($g as $img){$i++;?>
								<div data-thumb="<?=$i?>" class="item <?php if($i==1){echo'active';}?>">
<img src="<?=base_url().'uploads/'.$img->image?>" data-zoom-image="<?=base_url().'uploads/'.$img->image?>" alt="<?=$rows->barcode?>" class="img-responsive thumbnail zoom-img"/>
				            	</div>
<?php } ?>
                    		</div>
                  		</div> 
						<div class="clearfix">
                    		<div id="thumbcarousel" class="carousel slide" data-interval="false">
                      			<div class="carousel-inner">
<?php 
$i=-1; 
$this->load->model('modeldb'); 
$f = $this->modeldb->detailimg($rows->barcode); 
foreach($f as $img){ 
$i++;?>
		                        	<div data-target="#carousel" data-slide-to="<?=$i?>" class="thumb">
		                          		<img src="<?=base_url().'uploads/'.$img->image?>" alt="Image" class="img-responsive thumbnail">
		                          	</div>
<?php } ?>
                      			</div>
                      <a class="left carousel-control" href="#thumbcarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                      </a>
                      <a class="right carousel-control" href="#thumbcarousel" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                      </a>
                    </div>
                  		</div>
					</div>
				<!-- Left Ends -->
				<!-- Right Starts -->
			<div class="col-sm-8 product-details">
				<div class="panel-smart">
				<?php
                  $x = $this->db->where('barcode', $rows->barcode)->get('size');
                  if ($x->num_rows() > 0){
						$z = $x->row()->price;
					}else{
						return 0;
					}
                  ?>
				<!-- Product Name Starts -->
					<h2><?=$rows->nama?></h2>
				<!-- Product Name Ends -->
					<hr />
				<!-- Manufacturer Starts -->
					<?php
					$c = $this->modeldb->kat($rows->idkategori);
					?>
					<ul class="list-unstyled manufacturer">
						<li>
							<span>Brand:</span> Giani Gracio
						</li>
						<li>
							<span>Model:</span> <?=$rows->model?>
						</li>
						<li id="ava">
<!-- -->					<span>Availability:</span><strong class="label label-success">In Stock</strong>		 
						</li>
					</ul>
				<!-- Manufacturer Ends -->
					<hr />
				<!-- Price Starts -->
					<div class="price">
						<span class="price-head">Price :</span>
						<span class="price-new">Rp. <?=number_format($z,0,',','.')?>,-</span> 
						<!--<span class="price-old">$249.50</span>
						<p class="price-tax">Ex Tax: $279.99</p>-->
					</div>
				<!-- Price Ends -->
					<hr />
				<!-- Available Options Starts -->
				<?php echo form_open('home/add_cart/'.$rows->barcode); ?>
					<div class="options">
						<h3>Available Options</h3>
						<div class="form-group">
						
							<label for="select" class="control-label text-uppercase">Select Size:</label>
							<select name="size" id="size" class="form-control" onchange="sfunction(this.value)">
							<?php
							$a = $this->modeldb->getsize($rows->barcode);
							?>
							
								<option value="0" selected>Select Size</option>
								<?php foreach($a as $opt){?>
									<option value="<?=$opt->size?>"><?=$opt->size?></option>
								<?php } ?>
							</select>
						</div>	
						<div class="form-group">
							<label class="control-label text-uppercase" for="input-quantity">Qty:</label>
							<input type="text" name="quantity" value="1" size="2" id="input-quantity" class="form-control" />
						</div>
						<div class="cart-button button-group">
							<button type="button" class="btn btn-wishlist">
								<i class="fa fa-heart"></i>
							</button>

							<button id="add" type="submit" class="btn btn-cart" disabled>
								<i class="fa fa-shopping-cart"></i>			
								Add to cart
							</button>								
						</div>
					</div>
				<?php echo form_close()?>
				<!-- Available Options Ends -->
				</div>
			</div>
				<!-- Right Ends -->
				</div>
			<!-- product Info Ends -->
			<!-- Tabs Starts -->
		
		<div class="tabs-panel panel-smart">
		<!-- Nav Tabs Starts -->
			<ul class="nav nav-tabs" data-tabs="tabs">
				<li class="active">
					<a href="#description" data-toggle="tab">Description</a>
				</li>
				<li>
					<a href="#detail" data-toggle="tab">Detail</a>
				</li>
				<li><a href="#review" data-toggle="tab">Review</a></li>
			</ul>
		<!-- Nav Tabs Ends -->
		<!-- Tab Content Starts -->
			<div class="tab-content clearfix">
			<!-- Description Starts -->
				<div class="tab-pane active" id="description">
					<p><?=$rows->deskripsi?></p>
				</div>
			<!-- Description Ends -->
			<!-- Specification Starts -->
				<div class="tab-pane" id="detail">
					<table class="table table-bordered">
						<thead>
						  <tr>
							<td colspan="2"><strong>Name</strong></td>
						  </tr>
						</thead>
						<tbody>
						  <tr>
							<td>Name</td>
							<td>Attribute Specification</td>
						  </tr>
						</tbody>
					</table>
					<table class="table table-bordered">
						<thead>
						  <tr>
							<td colspan="2"><strong>Name</strong></td>
						  </tr>
						</thead>
						<tbody>
						  <tr>
							<td>Name</td>
							<td>Attribute Specification</td>
						  </tr>
						</tbody>
					</table>
				</div>
			<!-- Specification Ends -->

			<!-- Review Starts -->
				<div class="tab-pane" id="review">
					<div class="row">
						<div class="col-sm-12">
							<div class="notif" id="notif">
								<!--<div class="alert alert-success" id="alert"><i class="fa fa-check"></i> Thank you!</div>-->
							</div>
						</div>
						<div class="col-sm-12">
							<?php if($review == 0){?>
							&nbsp;
							<?php }else{?>
							<div class="well">
							<?php foreach($review as $rev){ ?>
                  				<div class="media">
                    				<div class="media-left" >
                      					<i class="fa fa-user fa-4x"></i>
                      					<div class="product-rating">
                      					<?php for($i = 0; $i < $rev->rating; $i++){ ?>
					                        <i class="fa fa-star"></i>
					                    <?php } ?>
					                    <?php if($rev->rating == '1'){?>
					                    	<i class="fa fa-star-o"></i>
					                    	<i class="fa fa-star-o"></i>
					                    	<i class="fa fa-star-o"></i>
					                    	<i class="fa fa-star-o"></i>
					                    <?php }elseif($rev->rating == '2'){?>
					                    	<i class="fa fa-star-o"></i>
					                    	<i class="fa fa-star-o"></i>
					                    	<i class="fa fa-star-o"></i>
					                    <?php }elseif($rev->rating == '3'){?>
					                    	<i class="fa fa-star-o"></i>
					                    	<i class="fa fa-star-o"></i>
					                    <?php }elseif($rev->rating == '4'){?>
					                    	<i class="fa fa-star-o"></i>
					                    <?php } ?>
                      					</div>
                    				</div>
                    				<div class="media-body">
                      					<h5 class="media-heading"><strong><?=$rev->nama?></strong></h5>
                      					<p><?=$rev->isireview?>.</p>
                    				</div>
                  				</div>                  			
						<?php } ?>
							</div>
							<?php } ?>
						</div>
					</div>
					
				
					<form class="form-horizontal" method="post" id="frmreview" >
						<div class="form-group required">
							<label class="col-sm-2 control-label" for="input-name">Name</label>
							<div class="col-sm-10">
							<input type="hidden" name="barcode" value="<?=$rows->barcode?>" id="barcode" class="form-control" />
							<input type="text" name="nama" id="nama" class="form-control" required/>
							</div>
						</div>
						<div class="form-group required">
							<label class="col-sm-2 control-label" for="input-review">Review</label>
							<div class="col-sm-10">
								<textarea rows="5" id="isi" class="form-control" name="review" required></textarea>
								<div class="help-block">
									Some note goes here..
								</div>
							</div>
						</div>
						<div class="form-group required">
							<label class="col-sm-2 control-label ratings">Ratings</label>
							<div class="col-sm-10">
								Bad&nbsp;
								<input type="radio" name="rating" value="1" id="rating"/>
								&nbsp;
								<input type="radio" name="rating" value="2" id="rating"/>
								&nbsp;
								<input type="radio" name="rating" value="3" id="rating" checked="true"/>
								&nbsp;
								<input type="radio" name="rating" value="4" id="rating"/>
								&nbsp;
								<input type="radio" name="rating" value="5" id="rating" />
								&nbsp;Good
							</div>
						</div>
						<div class="buttons">
							<div class="col-sm-offset-2 col-sm-10">
								<input type="submit" id="button-review" class="btn btn-main" value="Submit" />
							</div>
						</div>
					</form>
				</div>
			<!-- Review Ends -->
			</div>
		<!-- Tab Content Ends -->
		</div>
	<!-- Tabs Ends -->
	<?php
		$a = $rows->tag;
		$b = explode(',',$a);
		$c = count($b);
	?>
		<div class="tags">
			Product Tags  :
			<?php for ($i=0;$i < $c; $i++){ ?>
				<span>
					<a href="<?=base_url().'search-result?search='.$b[$i]?>" style="font-style: italic"><?php print_r($b[$i])?>, </a>
				</span>
			<?php } ?>
		</div>		
	<?php } ?>
		

	</div>
<?php
$data['kontak'] = $this->modeldb->setting(); 
$this->load->view('footer2', $data);
?>

<!-- The Modal -->
<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">              
      <div class="modal-body">
        <img src="" class="imagepreview image-thumbnail" style="width: 100%;" >
      </div>
    </div>
  </div>
 </div>
<!-- JavaScript Files -->

<script src="<?=base_url()?>assets/dist/bootstrap-notify.min.js"></script>
<script>
$(document).ready(function() {
	$("#button-review").click(function() {
		var nama = $('#nama').val();
		var review = $('#isi').val();
		if(nama == '' || review == '' ){
			$.notify({
				icon: 'fa fa-close',
				message: "Please Fill The Blank!"
			},{
				type:'danger',
				allow_dismiss: false,
				animate: {
					enter: 'animated fadeInRight',
					exit: 'animated fadeOutRight' 
				}
			});
		}else{
			$.ajax({
				type:"POST",
				url: "<?php echo site_url('home/addreview');?>",
				data:$("#frmreview").serialize(),
				success: function (dataCheck) {
	//				alert(dataCheck);
					$('div.notif').append(dataCheck);
					$('#frmreview')[0].reset();
				}
			});
		}
		
	});
});
function savereview(){
		var formData = $('#frmreview').serialize();	
		alert(formData)
		$.ajax({
			type:'post',
			url:"<?php echo base_url()?>home/addreview",
			data: formData,
			success:function(data){
				$('div.notif').html(data);
			}
		});
//		location.reload();
	}
$(function() {
		$('.item').on('click', function() {
			$('.imagepreview').attr('src', $(this).find('img').attr('src'));
			$('#imagemodal').modal('show');   
		});		
});
function sfunction(id) {
	var id;
    if(id != 0){
		document.getElementById('add')
        .removeAttribute('disabled');  
   		return false; 
		
	}else if(id == '0'){
		document.getElementById('add')
        .setAttribute('disabled', 'disabled');  
   		return false;
	}
}
$(document).ready(function(){
	$('.zoom-img').ezPlus({
		easing:true,
		responsive : true,
		scrollZoom: true
	});
});
</script>


</body>
</html>