<!-- Main Menu Starts -->
	<nav id="main-menu" class="navbar home" role="navigation">
	<!-- Nested Container Starts -->
		<div class="container">
		<!-- Nav Header Starts -->
			<div class="navbar-header">
				<button type="button" class="btn btn-navbar navbar-toggle" data-toggle="collapse" data-target=".navbar-cat-collapse">
					<span class="sr-only">Toggle Navigation</span>
					<i class="fa fa-bars"></i>
				</button>
			</div>
		<!-- Nav Header Ends -->
		<!-- Navbar Cat collapse Starts -->
			<div class="collapse navbar-collapse navbar-cat-collapse">
				<ul class="nav navbar-nav">
				<?php foreach($kategori as $list){?>
					<li><a href="<?=base_URL().'category/'.$list->id?>"><?=$list->namakat?></a></li>
				<?php } ?>
				</ul>
			</div>
		<!-- Navbar Cat collapse Ends -->
		</div>
	<!-- Nested Container Ends -->
	</nav>
<!-- Main Menu Ends -->