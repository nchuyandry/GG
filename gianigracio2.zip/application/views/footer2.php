<!-- Footer Section Starts -->
	<footer id="footer-area">
	<!-- Footer Links Starts -->
		<div class="footer-links">
		<!-- Container Starts -->
			<div class="container">
			<?php foreach($kontak as $row){?>
				<!-- Information Links Starts -->
					<div class="col-md-2 col-sm-4 col-xs-12">
						<h5>Information</h5>
						<ul>
							<li><a href="<?=base_url().'aboutus'?>">About Us</a></li>
							<li><a href="#">Delivery Information</a></li>
							<li><a href="<?=base_url().'privacy-policy'?>">Privacy Policy</a></li>
							<li><a href="<?=base_url().'terms-conditions'?>">Terms &amp; Conditions</a></li>
						</ul>
					</div>
				<!-- Information Links Ends -->
				<!-- My Account Links Starts -->
					<div class="col-md-2 col-sm-4 col-xs-12">
						<h5>My Account</h5>
						<?php if($this->session->userdata('email')){?>
						<ul>
							<li><a href="<?=base_url().'history'?>">My orders</a></li>
							<li><a href="#">My credit slips</a></li>
							<li><a href="#">My addresses</a></li>
							<li><a href="#">My personal info</a></li>
						</ul>
						<?php }else{?>
						<ul>
							<li><a href="<?=base_url().'register'?>">Register</a></li>
							<li><a href="<?=base_url().'userlogin'?>">Login</a></li>
						</ul>
						<?php } ?>
					</div>
				<!-- My Account Links Ends -->
				<!-- Customer Service Links Starts -->
					<div class="col-md-2 col-sm-4 col-xs-12">
						<h5>Service</h5>
						<ul>
							<li><a href="<?=base_url().'contact'?>">Contact Us</a></li>
							<li><a href="#">Returns</a></li>
							<li><a href="#">Site Map</a></li>
							<li><a href="#">Affiliates</a></li>
							<li><a href="#">Specials</a></li>
						</ul>
					</div>
				<!-- Customer Service Links Ends -->
				<!-- Follow Us Links Starts -->
					<div class="col-md-2 col-sm-4 col-xs-12">
						<h5>Follow Us</h5>
						<ul>
							<li><a href="https://<?=$row->fb?>">Facebook</a></li>
							<li><a href="https://<?=$row->twit?>">Twitter</a></li>
						</ul>
					</div>
				<!-- Follow Us Links Ends -->
				<!-- Contact Us Starts -->
					<div class="col-md-4 col-sm-8 col-xs-12 last">
						<h5>Contact Us</h5>
						<ul>
							<li>Company :</li>
							<li>
								<?=$row->address?>
							</li>
							<li>
								Email: <a href="mailto:<?=$row->email?>"><?=$row->email?></a>
							</li>								
						</ul>
						<h4 class="lead">
							Phone: <span><?=$row->phone?></span>
						</h4>
					</div>
				<!-- Contact Us Ends -->
			<?php } ?>
			</div>
		<!-- Container Ends -->
		</div>
	<!-- Footer Links Ends -->
	<!-- Copyright Area Starts -->
		<div class="copyright">
		<!-- Container Starts -->
			<div class="container">
			<!-- Starts -->
				<p class="pull-right">
					Copyright &copy; Giani Gracio 2016.
				</p>
			<!-- Ends -->
			</div>
		<!-- Container Ends -->
		</div>
	<!-- Copyright Area Ends -->
	</footer>
<!-- Footer Section Ends -->