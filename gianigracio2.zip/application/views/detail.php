<html ng-app="bigmoney" >
  <head>

	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.8/angular.min.js" ></script>
    <!-- SITE TITTLE -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BIG MONEY Store - Online Shop</title>
    
    <!-- PLUGINS CSS STYLE -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/animate.css">
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">

    <!-- GOOGLE FONT -->    
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    
    <!-- CUSTOM CSS -->
    <link href="<?=base_url()?>assets/css/homestyle.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>

<body>
<div class="main-wrapper" ng-controller="kontrol">
	<?php $this->load->view('topbar')?>
	<?php $this->load->view('navbar')?>
	<?php foreach($prod as $rows){ ?>
	<section class="lightSection clearfix pageHeader">
		<div class="container">
			<div class="row">
				<div class="col-xs-6">
					<div class="page-title">
						<h2><?=$rows->nama?></h2>
					</div>
					
				</div>
				<div class="col-xs-6">
					<ol class="breadcrumb pull-right">
	                <li><a href="index.html">Home</a></li>
	                <li class="active"><?=$rows->barcode?></li>
	              </ol>
				</div>
		</div>
	</div>
	</section>
	<section class="mainContent clearfix">
    	<div class="container">
        	<div class="row singleProduct">
              		<div class="media">
              			<div class="col-md-6">
                			<div class="media-left productSlider">
                  			<div id="carousel" class="carousel slide" data-ride="carousel">
                    			<div class="carousel-inner">
                     <?php 
	                     $i=0;
	                     $this->load->model('modeldb');
	                     $g = $this->modeldb->detailimg($rows->barcode);
	                     foreach($g as $img){
	                     	$i++;
					 ?>
									<div data-thumb="<?=$i?>" class="item <?php if($i==1){echo'active';}?>">
				                    	<img src="<?=base_url().'uploads/'.$img->image?>">
				                    </div>
                    <?php } ?>
                    			</div>
                  			</div> 
                  		<div class="clearfix">
                    		<div id="thumbcarousel" class="carousel slide" data-interval="false">
                      			<div class="carousel-inner">
                    <?php 
	                     $i=-1;
	                     $this->load->model('modeldb');
	                     $f = $this->modeldb->detailimg($rows->barcode);
	                     foreach($f as $img){
	                     	$i++;
	                     	
					 ?>
		                          <div data-target="#carousel" data-slide-to="<?=$i?>" class="thumb">
		                          	<img src="<?=base_url().'uploads/'.$img->image?>">
		                          </div>
                          
                    <?php } ?>
                      			</div>
                      <a class="left carousel-control" href="#thumbcarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                      </a>
                      <a class="right carousel-control" href="#thumbcarousel" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                      </a>
                    </div>
                  </div>
                </div>
						</div>
						<div class="col-md-6">
                			<div class="media-body">
                  <ul class="list-inline">
                    <li><a href="index.html"><i class="fa fa-reply" aria-hidden="true"></i>Continue Shopping</a></li>
                    <li><a href="#"><i class="fa fa-plus" aria-hidden="true"></i>Share This</a></li>
                  </ul>
                  <h2><?=$rows->nama?></h2>
                  
                  <?php
                  $x = $this->db->where('barcode', $rows->barcode)->get('size');
                  if ($x->num_rows() > 0){
						$z = $x->row()->price;
					}else{
						return 0;
					}
                  ?>
                  
                  <h3>Rp. <?=number_format($z,0,',','.')?>,-</h3>
                  <span class="quick-drop">
                    <select name="guiest_id3" id="guiest_id3" class="form-control select-drop">
                      <option value="0">Size</option>
                      <option value="1">Small</option>
                      <option value="2">Medium</option>
                      <option value="3">Big</option>            
                    </select>
                  </span>
                  <span class="quick-drop resizeWidth">
                    <select name="guiest_id4" id="guiest_id4" class="select-drop">
                      <option value="0">Qty</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>            
                    </select>
                  </span>
                  <div class="btn-area">
                    <a href="#" class="btn btn-primary btn-block">Add to cart <i class="fa fa-angle-right" aria-hidden="true"></i></a> 
                  </div>
                  <div class="tabArea">
                    <ul class="nav nav-tabs">
                      <li class="active"><a data-toggle="tab" href="#details">Description</a></li>
                      <li><a data-toggle="tab" href="#about-art">about art</a></li>
                      <li><a data-toggle="tab" href="#sizing">sizing</a></li>
                      <li><a data-toggle="tab" href="#shipping">shipping</a></li>
                    </ul>
                    <div class="tab-content">
                      <div id="details" class="tab-pane fade in active">
                        <p><?= $rows->deskripsi?></p>
                        
                      </div>
                      <div id="about-art" class="tab-pane fade">
                        <p>Nulla facilisi. Mauris efficitur, massa et iaculis accumsan, mauris velit ultrices purus, quis condimentum nibh dolor ut tortor. Donec egestas tortor quis mattis gravida. Ut efficitur elit vitae dignissim volutpat. </p>
                      </div>
                      <div id="sizing" class="tab-pane fade">
                        <p>Praesent dui felis, gravida a auctor at, facilisis commodo ipsum. Cras eu faucibus justo. Nullam varius cursus nisi, sed elementum sem sagittis at. Nulla tellus massa, vestibulum a commodo facilisis, pulvinar convallis nunc.</p>
                      </div>
                      <div id="shipping" class="tab-pane fade">
                        <p>Mauris lobortis augue ex, ut faucibus nisi mollis ac. Sed volutpat scelerisque ex ut ullamcorper. Cras at velit quis sapien dapibus laoreet a id odio. Sed sit amet accumsan ante, eu congue metus. Aenean eros tortor, cursus quis feugiat sed, vestibulum vel purus.</p>
                      </div>
                    </div>
                  </div>
                </div>
						</div>
              		</div>
          	</div>
          	<div class="row productsContent">
	            <div class="col-xs-12">
	              <div class="page-header">
	                <h4>Related Products</h4>
	              </div>
	            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="productBox">
                <div class="productImage clearfix">
                  <img src="img/products/products-01.jpg" alt="products-img">
                  <div class="productMasking">
                    <ul class="list-inline btn-group" role="group">
                      <li><a data-toggle="modal" href=".login-modal" class="btn btn-default"><i class="fa fa-heart"></i></a></li>
                      <li><a href="cart-page.html" class="btn btn-default"><i class="fa fa-shopping-cart"></i></a></li>
                      <li><a class="btn btn-default" data-toggle="modal" href=".quick-view" ><i class="fa fa-eye"></i></a></li>
                    </ul>
                  </div>
                </div>
                <div class="productCaption clearfix">
                 <h5>Nike Sportswear</h5>
                 <h3>$199</h3>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="productBox">
                <div class="productImage clearfix">
                  <img src="img/products/products-02.jpg" alt="products-img">
                  <div class="productMasking">
                    <ul class="list-inline btn-group" role="group">
                      <li><a data-toggle="modal" href=".login-modal" class="btn btn-default"><i class="fa fa-heart"></i></a></li>
                      <li><a href="cart-page.html" class="btn btn-default"><i class="fa fa-shopping-cart"></i></a></li>
                      <li><a class="btn btn-default" data-toggle="modal" href=".quick-view" ><i class="fa fa-eye"></i></a></li>
                    </ul>
                  </div>
                </div>
                <div class="productCaption clearfix">
                 <h5>Dip Dyed Sweater</h5>
                 <h3>$249</h3>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="productBox">
                <div class="productImage clearfix">
                  <img src="img/products/products-03.jpg" alt="products-img">
                  <div class="productMasking">
                    <ul class="list-inline btn-group" role="group">
                      <li><a data-toggle="modal" href=".login-modal" class="btn btn-default"><i class="fa fa-heart"></i></a></li>
                      <li><a href="cart-page.html" class="btn btn-default"><i class="fa fa-shopping-cart"></i></a></li>
                      <li><a class="btn btn-default" data-toggle="modal" href=".quick-view" ><i class="fa fa-eye"></i></a></li>
                    </ul>
                  </div>
                </div>
                <div class="productCaption clearfix">
                 <h5>Scarf Ring Corner</h5>
                 <h3>$179</h3>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="productBox">
                <div class="productImage clearfix">
                  <img src="img/products/products-04.jpg" alt="products-img">
                  <div class="productMasking">
                    <ul class="list-inline btn-group" role="group">
                      <li><a data-toggle="modal" href=".login-modal" class="btn btn-default"><i class="fa fa-heart"></i></a></li>
                      <li><a href="cart-page.html" class="btn btn-default"><i class="fa fa-shopping-cart"></i></a></li>
                      <li><a class="btn btn-default" data-toggle="modal" href=".quick-view" ><i class="fa fa-eye"></i></a></li>
                    </ul>
                  </div>
                </div>
                <div class="productCaption clearfix">
                 <h5>Sun Buddies</h5>
                 <h3>$149</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

	<?php } ?>

</div>
	<script src="<?=base_url()?>assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/wow.min.js" type="text/javascript"></script>
	<script>
		var app=angular.module('bigmoney',[]);
		app.controller('kontrol',function($scope,$http){
    		$scope.products=[];
    		$http.get("<?php echo base_url('home/viewdata');?>").success(function(result){
     		$scope.products=result;
    	});
    
   		});
	</script>
	<script>
    	new WOW().init();
    	$(window).scroll(function(){
    		if($(this).scrollTop()>20){
				$(".featuredCollection").addClass('fadeInDown');
			}
    	});
    	$(window).scroll(function(){
    		if($(this).scrollTop()>20){
				$(".featuredProducts").addClass('fadeInDown');
			}
    	});
    </script>
</body>
</html>