
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Administrator Page | Giani Gracio Shop Online</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
	
    <!--  Light Bootstrap Dashboard core CSS    -->
   	<link href="<?=base_url()?>assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>

	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
</head>
<body>

<div class="wrapper">
    <?php $this->load->view('adminpage/sidebar')?>

    <div class="main-panel">
        <?php 
        $data['title'] = 'Detail Order';
        $this->load->view('adminpage/header' , $data);
        ?>

        <div class="content" id="content">
            <div class="container-fluid">
			<?php 
			$date = date('d:m:Y');
			foreach($invoices as $row){
			?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card ">
                            <div class="header">
								<h4 class="title">
									Detail Order <u><b><?=$row->id?></b></u>
									<div class="pull-right"><?=$date?></div>
								</h4>
                            </div>
                            <div class="content" id="printarea">
								
								<div class="row">
					           		<div class="col-sm-6">
					                	<?php if($row->status == 'Uncompleted'){ ?>
											<h5><span class="label label-warning"><?=$row->status?></span></h5>
										<?php }elseif($row->status == 'Confirmed'){ ?>
											<h5><span class="label label-info"><?=$row->status?></span></h5>
										<?php }elseif($row->status == 'Completed'){ ?>
											<h5><span class="label label-success"><?=$row->status?></span></h5>
										<?php }elseif($row->status == 'Canceled'){ ?>
											<h5><span class="label label-danger"><?=$row->status?></span></h5>
										<?php }else{ ?>
											<h5><span class="label label-default"><?=$row->status?></span></h5>
										<?php }?>
					            	</div>
					             	<div class="col-sm-6">
					           			<ul class="list-inline order-action pull-right">
					           				<li>
					                    		<a onclick="printpage()" class="btn btn-sm" id="printpage">
					                    			<i class="fa fa-print"></i> 
					                    			Print
					                    		</a>
					                    	</li>
					                    	<li>
					           					<a href="<?=base_url().'admin/invoices'?>" id="back" class="btn btn-sm ">
												<i class="fa fa-rotate-left"></i> Back
												</a>
					           				</li>
					               		</ul>
					            	</div>
          						</div>
								<div class="row">
<?php
$this->load->model('modeldb');
$x = $this->modeldb->getcus($row->user_id);
foreach($x as $list){
?>
                					<div class="col-md-6">
                    					<div class="panel panel-default" style="border-bottom: 0">
                       						<div class="panel-heading"><h4 class="panel-title">Billing Address / Shipping Address</h4></div>
                       						<div class="panel-body" >
	                        					<ul class="list-unstyled">
				                                    <li><b><?=$list->firstname?></b></li>
				                                    <li><?=$list->address1?></li>
				                                    <li><?=$list->city?>, <?=$list->province?></li>
				                                    <li><?=$list->country?></li>
				                                    <li><b>Email: </b><?=$list->email?></li>
	                                  				<li><b>Phone: </b><?=$list->phone?></li>
			                                   	</ul>
                         					</div>
                      					</div>
                   					</div>
                 					<div class="col-md-6">
                 						<div class="panel panel-default" style="border-bottom: 0">
                 							<div class="panel-heading"></div>
                 							<div class="panel-body">
                 								<?php if($row->image != false){?>
		                                		<img src="<?=base_url().'uploads/'.$row->image?>" class="pull-right img-thumbnail" width="200;" alt="Payment Slip" id="payment"/>
		                                		<?php }else{ ?>
													<h3 class="text-center" title="Payment Slip" id="payment">No Image</h3>
												<?php } ?>
                 							</div>
                 						</div>
                					</div>
               					</div>
            					<div class="products-order">
									<div class="table-responsive">
                						<table class="table table-products table-bordered">
				                    	<thead>
											<tr>
												<th class="col-xs-1 text-center"">#</th>
												<th class="col-xs-1 text-center"">Image</th>
												<th class="col-xs-2 text-center"">Barcode</th>
												<th class="col-xs-2 text-center">Qty</th>
												<th class="col-xs-2 col-md-1 text-center">Price</th>
												<th class="col-xs-2 text-center">Subtotal</th>
											</tr>
				        				</thead>
                      					<tbody>
<?php 
$i = 0;
$tot = 0;
foreach($orders as $item){
$i++;
$qty = $item->qty;
$price = $item->price;
$subtotal = $qty * $price;
$tot += $subtotal;
$disc = $tot * 0.25;
$total = $tot - $disc;
?>
			                        		<tr>
			                            		<td class="col-xs-1  text-center"><?=$i?></td>
			                              		<td class="col-xs-1  text-center"><img src="<?=base_url().'uploads/'.$item->image?>" alt="" class="img-responsive"></td>
			                                 	<td class="col-xs-2  text-center"><a href="#"><?=$item->barcode?></a></td>
			                                 	<td class="col-xs-2 text-center"><?=$qty?> items</td>
			                                  	<td class="col-xs-2 col-md-1 text-center">Rp. <?=number_format($price,0,',','.')?>,-</td>
			                                  	<td class="col-xs-2 text-center"><span><b>Rp. <?=number_format($subtotal,0,',','.')?>,-</b></span></td>
			                              	</tr>
										</tbody>
<?php } ?>
										<tfoot >
											<tr>
												<td colspan="4"></td>
							        			<td class="col-xs-2 col-md-1 text-center"><strong>Subtotal</strong></td>
							        			<td class="col-xs-2 text-center"><b>Rp. <?=number_format($tot,0,',','.')?>,-</b></td>
							        		</tr>
											<tr>
												<td colspan="4"></td>
							        			<td class="col-xs-2 col-md-1 text-center"><strong>Disc -25%</strong></td>
							        			<td class="col-xs-2 text-center"><b>Rp. <?=number_format($disc,0,',','.')?>,-</b></td>
							        		</tr>
							        		<tr>
							        			<td colspan="4"></td>
							        			<td class="col-xs-2 col-md-1 text-center"><strong>Total</strong></td>
							        			<td class="col-xs-2 text-center"><b>Rp. <?=number_format($total,0,',','.')?>,-</b></td>
							        		</tr>
										</tfoot>
                 						</table>
									</div>                    
            					</div>
								<?php } ?>
							</div>
                    	</div>
                	</div>
            	</div>
            <?php } ?>
        	</div>
    	</div>

        <?php $this->load->view('adminpage/footer')?>


</div>
</div>


</body>
    <!--   Core JS Files and PerfectScrollbar library inside jquery.ui   -->
    <script src="<?=base_url()?>assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script>
		function print_window(){
			var printContents = document.getElementById("printarea").innerHTML;
    		var originalContents = document.body.innerHTML;
		    document.body.innerHTML = printContents;/*
		    document.getElementById('printpage').style.visibility = 'hidden';
		    document.getElementById('balik').style.visibility = 'hidden';*/
		    window.print();
		    document.body.innerHTML = originalContents;
		}    
		function printpage() {

	        var printcontent = document.getElementById("printarea").innerHTML;

	        document.getElementById('printpage').style.visibility = 'hidden';
	        document.getElementById('back').style.visibility = 'hidden';/*
	        document.getElementById('payment').style.visibility = 'hidden';*/
	        $('#payment').hide();
	        $('.footer').css('visibility','hidden');
	        $('.table-responsive').css('overflow-x','hidden');
	        window.print(printcontent);
			document.getElementById('printpage').style.visibility = 'visible';
	        document.getElementById('back').style.visibility = 'visible';
	        $('#payment').show();
	        $('.footer').css('visibility','visible');
	    }
	</script>

	<!--  Forms Validations Plugin -->
	<script src="../assets/js/jquery.validate.min.js"></script>

	<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
	<script src="../assets/js/moment.min.js"></script>

    <!--  Date Time Picker Plugin is included in this js file -->
    <script src="../assets/js/bootstrap-datetimepicker.js"></script>

    <!--  Select Picker Plugin -->
    <script src="../assets/js/bootstrap-selectpicker.js"></script>

	<!--  Checkbox, Radio, Switch and Tags Input Plugins -->
	<script src="../assets/js/bootstrap-checkbox-radio-switch-tags.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Sweet Alert 2 plugin -->
	<script src="../assets/js/sweetalert2.js"></script>

    <!-- Vector Map plugin -->
	<script src="../assets/js/jquery-jvectormap.js"></script>

    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Wizard Plugin    -->
    <script src="../assets/js/jquery.bootstrap.wizard.min.js"></script>

    <!--  Datatable Plugin    -->
    <script src="../assets/js/bootstrap-table.js"></script>

    <!--  Full Calendar Plugin    -->
    <script src="../assets/js/fullcalendar.min.js"></script>

    <!-- Light Bootstrap Dashboard Core javascript and methods -->
	<script src="<?=base_url()?>assets/js/light-bootstrap-dashboard.js"></script>

	<!--   Sharrre Library    -->
    <script src="../assets/js/jquery.sharrre.js"></script>

	<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	<script>
		$(document).ready(function(){
		    $('[data-toggle="tooltip"]').tooltip(); 
		});
	</script>

</html>
