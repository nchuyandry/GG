
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Administrator Page | Giani Gracio Shop Online</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
	
    <!--  Light Bootstrap Dashboard core CSS    -->
    <link href="<?=base_url()?>assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
	
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
</head>
<body>

<div class="wrapper">
    <?php $this->load->view('adminpage/sidebar')?>

    <div class="main-panel">
        <?php 
        $data['title'] = 'Dashboard';
        $this->load->view('adminpage/header', $data);
        ?>

        <div class="content">
            <div class="container-fluid">
            	<form enctype="multipart/form-data" action="<?=base_url().'admin/addproduct'?>" method="POST" class="form-horizontal" >
                <div class="row">
                    <div class="col-md-12">
                        <div class="card ">
                            <div class="header">
                                <h4 class="title">Add Product 
                                <button type="submit" class="btn btn-success pull-right" value="save"><i class="fa fa-floppy-o"></i> Save Product</button>
                                </h4>
                                <!--<p class="category"></p>-->
                                <?php if(validation_errors() != false) { ?>
				<br /><div class="alert alert-danger" id="alert"><i class="fa fa-close"></i>Field Required</div>
                                <?php } ?>

                                
                            </div>
                            <div class="content">
                            	<ul role="tablist" class="nav nav-tabs">
                                    <li role="presentation" class="active">
                                        <a href="#general" data-toggle="tab">General Data</a>
                                    </li>
                                    <li>
                                        <a href="#option" data-toggle="tab">Option</a>
                                    </li> 
                                    <li>
                                        <a href="#image" data-toggle="tab">Image</a>
                                    </li>                                   
                                </ul>
                                <div class="tab-content">
                                    <div id="general" class="tab-pane active">
                                    	<div class="row">
                                    	<div class="col-md-6">
                                    		<div class="form-group">
		                                    	<label class="col-md-4 control-label">Date Input</label>
		                                       	<div class="col-md-8">
		                                    	<input type="datetime" class="form-control" name="tgl" value="<?=date('Y-m-d H:i:s')?>" />
		                                    	</div>
		                                    </div>
		                                    <div class="form-group">
		                                        <label class="col-md-4 control-label">Barcode</label>
		                                        	<div class="col-md-8">
		                                        		<input type="text" class="form-control" name="barcode" />
		                                        	</div>
		                                        </div>
		                                    	<div class="form-group">
		                                        	<label class="col-md-4 control-label">Product Name</label>
		                                        	<div class="col-md-8">
		                                        		<input type="text" class="form-control" name="nama" />
		                                        	</div>
		                                        </div>
		                                    	<div class="form-group">
		                                        	<label class="col-md-4 control-label">Description</label>
		                                        	<div class="col-md-8">
		                                        		<textarea class="form-control" name="deskripsi"></textarea>
		                                        	</div>
		                                        </div>
		                                    	<div class="form-group">
		                                        	<label class="col-md-4 control-label">Tag Keywords</label>
		                                        	<div class="col-md-8">
		                                        		<input name="tagsinput" class="tagsinput tag-azure form-control" value="" />
		                                        	</div>
		                                        </div>
                                    	</div>
		                                <div class="col-md-6">    	
		                                    <div class="form-group">
		                                        	<label class="col-md-4 control-label">Category</label>
		                                        	<div class="col-md-8">
		                                        		<select class="form-control" name="kategori" onclick="getM()" id="kateg" required>
		                                        		<?php foreach($kat as $r){?>
		                                        			<option value="<?=$r->id?>"><?=$r->namakat?></option>
		                                        		<?php } ?>
		                                        		</select>
		                                        	</div>
		                                    </div>
		                                    <div class="form-group">
		                                        	<label class="col-md-4 control-label">Model</label>
		                                        	<div class="col-md-8">
		                                        		<input type="text" name="model" class="form-control" value="" id="model"/>
		                                        	</div>
		                                    </div>
		                                    <div class="form-group">
		                                        	<label class="col-md-4 control-label">Status</label>
		                                        	<div class="col-md-8">
		                                        		<select class="form-control" name="status">
		                                        			<option value="Enabled">Enabled</option>
		                                        			<option value="Disabled">Disabled</option>
		                                        		</select>
		                                        	</div>
		                                        </div>
		                                    <div class="form-group">
		                                        	<label class="col-md-4 control-label">featured Product</label>
		                                        	<div class="col-md-8">
		                                        		<select class="form-control" name="featured">
		                                        			<option value="No">No</option>
		                                        			<option value="Yes">Yes</option>
		                                        		</select>
		                                        	</div>
		                                        </div>
		                                    <div class="form-group">
			                                    	<label class="col-md-4 control-label">Image</label>
			                                    	<div class="col-md-8">
			                                        	<input type="file" class="form-control" name="img[]" />
			                                        </div>
			                                 	</div>
                                    	</div>
                                    	</div>
                                    </div>
                                    <div id="option" class="tab-pane">
                                    	<h4 class="title" style="padding-bottom: 20px"><a class="btn btn-info pull-right" onclick="add()" style="cursor:pointer;text-decoration:none;"><i class="fa fa-plus"></i> Add Option</a></h4>
                                    	<div class="form-group">
                                    		<label class="col-md-2 control-label">Product Size</label>
                                    		<div class="col-md-4">
                                    			<input type="text" class="form-control" name="size[]" required />
                                    		</div>
                                    	</div>
                                    	<div class="form-group">
                                    	<label class="col-md-2 control-label">Quantity</label>
                                    		<div class="col-md-4">
                                    			<input type="number" class="form-control" name="qty[]" required />
                                    		</div>
                                    	</div>
                                    	<div class="form-group">
                                    		<label class="col-md-2 control-label">Price</label>
                                    		<div class="col-md-4">
                                    			<input type="number" class="form-control" name="price[]" required />
                                    		</div>
                                    	</div>
                                    	<hr/>
                            		</div>
									<div id="image" class="tab-pane">
										<h4 class="title" style="padding-bottom: 20px"><a class="btn btn-info pull-right" onclick="addimg()" style="cursor:pointer;text-decoration:none;"><i class="fa fa-plus"></i> Add Image</a></h4>
										<div class="form-group">
											<label class="col-md-2 control-label">Image</label>
											<div class="col-md-4">
												<input type="file" class="form-control" name="img[]" required />
											</div>
										</div>
									</div>
								</div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            </div>
        </div>


        <?php $this->load->view('adminpage/footer')?>

    </div>
</div>


</body>
    <!--   Core JS Files and PerfectScrollbar library inside jquery.ui   -->
    <script src="<?=base_url()?>assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/bootstrap.min.js" type="text/javascript"></script>


	<!--  Forms Validations Plugin -->
	<script src="../assets/js/jquery.validate.min.js"></script>

	<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
	<script src="../assets/js/moment.min.js"></script>

    <!--  Date Time Picker Plugin is included in this js file -->
    <script src="../assets/js/bootstrap-datetimepicker.js"></script>

    <!--  Select Picker Plugin -->
    <script src="../assets/js/bootstrap-selectpicker.js"></script>

	<!--  Checkbox, Radio, Switch and Tags Input Plugins -->
	<script src="<?=base_url()?>assets/js/bootstrap-checkbox-radio-switch-tags.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Sweet Alert 2 plugin -->
	<script src="../assets/js/sweetalert2.js"></script>

    <!-- Vector Map plugin -->
	<script src="../assets/js/jquery-jvectormap.js"></script>

    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Wizard Plugin    -->
    <script src="../assets/js/jquery.bootstrap.wizard.min.js"></script>

    <!--  Datatable Plugin    -->
    <script src="../assets/js/bootstrap-table.js"></script>

    <!--  Full Calendar Plugin    -->
    <script src="../assets/js/fullcalendar.min.js"></script>

    <!-- Light Bootstrap Dashboard Core javascript and methods -->
	<script src="<?=base_url()?>assets/js/light-bootstrap-dashboard.js"></script>

	<!--   Sharrre Library    -->
    <script src="../assets/js/jquery.sharrre.js"></script>

	<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	<script>
	function getM(){
		var value = $("select[name='kategori'] option:selected").text();
		$('#model').val(value);
	}
	$(document).ready( function() {
	    var now = new Date();
	    var month = (now.getMonth() + 1);               
	    var day = now.getDate();
	    if(month < 10) 
	        month = "0" + month;
	    if(day < 10) 
	        day = "0" + day;
	    var today = now.getFullYear() + '-' + month + '-' + day;
	    $('#').val(today);
	});
		function add(){
			$("#option").append('<div class="form-group"><label class="col-md-2 control-label">Product Size</label><div class="col-md-4"><input type="text" class="form-control" name="size[]" /></div></div><div class="form-group"><label class="col-md-2 control-label">Quantity</label><div class="col-md-4"><input type="number" class="form-control" name="qty[]" required /></div></div><div class="form-group"><label class="col-md-2 control-label">Price</label><div class="col-md-4"><input type="number" class="form-control" name="price[]" /></div></div><hr/>').children(':last');
		}
		function addimg(){
			$("#image").append('<div class="form-group"><label class="col-md-2 control-label">Image</label><div class="col-md-4"><input type="file" class="form-control" name="img[]" /></div></div>').children(':last');
		}
	</script>

</html>
