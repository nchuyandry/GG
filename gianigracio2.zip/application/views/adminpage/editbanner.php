
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Administrator Page | Giani Gracio Shop Online</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
	
    <!--  Light Bootstrap Dashboard core CSS    -->
    <link href="<?=base_url()?>assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
</head>
<body>

<div class="wrapper">
    <?php $this->load->view('adminpage/sidebar')?>

    <div class="main-panel">
        <?php 
        $data['title'] = 'Setting Slider';
        $this->load->view('adminpage/header' , $data);
        ?>

        <div class="content">
            <div class="container-fluid">
<?php $this->session->flashdata("sukses")?>
				<div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="header">Edit Banner</div>
                            <div class="content">
                                <form method="post" action="<?=base_url().'admin/updatebanner'?>" enctype="multipart/form-data" >
                                <?php foreach($edit_banner as $r){?>
                                    <div class="form-group">
                                        <label>Title</label>
                                        <input type="hidden" value="<?=$r->id?>" name="id" class="form-control" required>
                                        <input type="text" value="<?=$r->title?>" name="title" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control" name="deskripsi" placeholder="Description" required><?=$r->description?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Image&nbsp;&nbsp;<small>*file type PNG</small></label>
                                        <input type="file" name="slideimg" class="form-control" value="<?=$r->image?>"/>
                                    </div>
                                    <button type="submit" class="btn btn-fill btn-info"><i class="fa fa-save"></i> Save Data</button>
                                <?php } ?>
                                </form>
                            </div>
                        </div> <!-- end card -->
                    </div>

                    <div class="col-md-8">
                        <div class="card">
                        <form action="<?=base_url().'admin/deletebanner'?>" class="form-horizontal" method="post">
                            <div class="header">All Slider  
<button type="submit" class="btn btn-danger pull-right btn-xs" value="Delete" onclick="return confirm('Are you sure want to delete this data?')"><i class="fa fa-trash"></i> 
                            	Delete Selected</button>
                            </div>
                            <div class="content">
                            	<div class="table-responsive">
                                	<table id="tcategory" class="table table-striped table-hover" >
						        	<thead>
										<tr>
											<th><input type="checkbox" id="select-all" /></th>
											<th style="text-align: left;">No.</th>
											<th style="text-align: left;">Title</th>
											<th style="text-align: left;">Description</th>
											<th style="text-align: left;">Image</th>
											<th>Action</th>
										</tr>
						        	</thead>
						        	<tbody>
						        		<?php 
						        			$no = 0;
						        			foreach($slider as $row):
						        			$no++;	
						        		?>
						        		<tr>
						        			<td><input type="checkbox" name="msg[]" value="<?=$row->id?>"></td>
						        			<td><?=$no?></td>
						        			<td><?=$row->title?></td>
						        			<td><?=$row->description?></td>
						        			<td><img src="<?=base_url().'uploads/'.$row->image?>" width="80"/></td>
						        			<td>
						        				<a href="<?=base_url()."admin/editbanner/".$row->id?>" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
						        			</td>
						        		</tr>	
						        		<?php endforeach; ?>
						        	</tbody>
       							</table>
                            	</div>
                            </div>
                            </form>
                    	</div>
                	</div>
               </div>
                
            </div><!--container-fluid-->
        </div><!--content-->


        <?php $this->load->view('adminpage/footer')?>

    </div>
</div>

	<script src="<?=base_url()?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/bootstrap.min.js" type="text/javascript"></script>


    <!-- Light Bootstrap Dashboard Core javascript and methods -->
	<script src="<?=base_url()?>assets/js/light-bootstrap-dashboard.js"></script>

	<script>
		$(document).ready(function(){
		    $('[data-toggle="tooltip"]').tooltip(); 
		});
		$(document).ready(function(){   
       		$('#select-all').on('click', function(){
       			if(this.checked){
					$(':checkbox').each(function(){
						this.checked = true;
					});
				}else {
					$(':checkbox').each(function() {
						this.checked = false;
					});
				}
       		});
    	});
	</script>

</body>
</html>
