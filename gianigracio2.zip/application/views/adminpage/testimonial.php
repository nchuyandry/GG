
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Administrator Page | Giani Gracio Shop Online</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
	
    <!--  Light Bootstrap Dashboard core CSS    -->
    <link href="<?=base_url()?>assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    <link href="<?=base_url()?>assets/dist/sweetalert.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

	<script src="//cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/dist/sweetalert.min.js"></script>
    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
</head>
<body>

<div class="wrapper">
    <?php $this->load->view('adminpage/sidebar')?>

    <div class="main-panel">
        <?php 
        $data['title'] = 'Testimonials';
        $this->load->view('adminpage/header' , $data);
        ?>

        <div class="content">
            <div class="container-fluid">
<?=$this->session->flashdata('sukses')?>
				<div class="row">
                    <div class="col-md-5">
                        <div class="card">
                        <form action="<?=base_url().'admin/deltes'?>" class="form-horizontal" method="post">
                            <div class="header">All Testimonials 
<button id="hapus" type="submit" class="btn btn-danger pull-right btn-xs" value="Delete"><i class="fa fa-trash"></i> 
                            	Delete Selected</button>
                            <!--return confirm('Are you sure want to delete this data?')-->
                            </div>
                            <div class="content">
                            	<div class="table-responsive">
                                	<table id="tcategory" class="table table-striped table-hover" >
						        	<thead>
										<tr>
											<th><input type="checkbox" id="select-all" /></th>
											<th style="text-align: left;">Customer Name</th>
											<th style="text-align: left;">Status</th>
											<th>Action</th>
										</tr>
						        	</thead>
						        	<tbody>
						        	<?php foreach($testimonial as $x):?>
						        		<tr>
						        			<td><input type="checkbox" name="msg[]" value="<?=$x->id?>" id="cek"></td>
						        			<td><?=$x->namakustomer?></td>
						        			<td><?=$x->status?></td>
						        			<td>
						        				<a href="<?=base_url().'admin/edittesti/'.$x->id?>" class="btn btn-sm btn-warning" title="Edit"><i class="fa fa-pencil"></i></a>
						        			</td>
						        		</tr>
						        	<?php endforeach; ?>	
						        	</tbody>
       							</table>
                            	</div>
                            </div>
                            </form>
                    	</div>
                	</div>
					<div class="col-md-7">
                        <div class="card">
                            <div class="header">Add Testimonial</div>
                            <div class="content">
                                <form method="POST" action="<?=base_url().'admin/addtesti'?>">
                                    <div class="form-group">
                                        <label>Customer Name</label>
                                        <input type="text" placeholder="Customer Name" name="cusname" class="form-control" required />
                                    </div>
                                    <div class="form-group">
                                        <label>Job Position</label>
                                        <input type="text" placeholder="Job Name" name="job" class="form-control" required />
                                    </div>
                                    <div class="form-group">
                                        <label>Content</label>
                                        <textarea class="form-control" name="content" placeholder="Content" required></textarea>
                                        <script> CKEDITOR.replace('content'); </script>
                                    </div>
                                    <div class="form-group">
                                        <label>Customer Name</label>
                                        <select name="status" class="form-control" required>
                                        	<option>Enabled</option>
                                        	<option>Disabled</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-fill btn-info"><i class="fa fa-save"></i> Save Category</button>
                                </form>
                            </div>
                        </div> <!-- end card -->
                    </div>
               </div>
                
            </div><!--container-fluid-->
        </div><!--content-->


        <?php $this->load->view('adminpage/footer')?>

    </div>
</div>

	<script src="<?=base_url()?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/bootstrap.min.js" type="text/javascript"></script>


    <!-- Light Bootstrap Dashboard Core javascript and methods -->
	<script src="<?=base_url()?>assets/js/light-bootstrap-dashboard.js"></script>

	<script>
		$(document).ready(function(){
		    $('[data-toggle="tooltip"]').tooltip(); 
		});
		$(document).ready(function(){   
       		$('#select-all').on('click', function(){
       			if(this.checked){
					$(':checkbox').each(function(){
						this.checked = true;
					});
				}else {
					$(':checkbox').each(function() {
						this.checked = false;
					});
				}
       		});
    	});
		$(document).ready(function(){
			$('#hapus').on('click',function(e){
			    e.preventDefault();
			    var form = $(this).parents('form');
			    swal({
			        title: "Are you sure?",
			        text: "Data will be deleted!",
			        type: "warning",
			        showCancelButton: true,
			        confirmButtonColor: "#DD6B55",
			        confirmButtonText: "Yes, delete it!",
			        closeOnConfirm: false
			    }, function(isConfirm){
			        if (isConfirm){
			        	form.submit();
			       		swal("Deleted!", "Data has been deleted.", "success");
			    	}
			    });
			})
		});
	</script>

</body>
</html>
