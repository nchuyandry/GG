
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Administrator Page | Giani Gracio Shop Online</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
	
    <!--  Light Bootstrap Dashboard core CSS    -->
    <link href="<?=base_url()?>assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
	
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
</head>
<body>

<div class="wrapper">
    <?php $this->load->view('adminpage/sidebar')?>

    <div class="main-panel">
        <?php 
        $data['title'] = 'Edit Review';
        $this->load->view('adminpage/header', $data);
        ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card ">
							<form action="<?=base_url().'admin/updaterev'?>" method="POST" class="form-horizontal" >
							<?php foreach($editrev as $row){ ?>
                            <div class="header">
                                <h4 class="title">Edit Review
                                <a href="<?=base_url().'admin/reviews'?>" class="btn btn-default pull-right"><i class="fa fa-rotate-left"></i> Back</a>
                                </h4>
                                <!--<p class="category"></p>-->
                                <?php if(validation_errors() != false) { ?>
				<br /><div class="alert alert-danger" id="alert"><i class="fa fa-close"></i>Field Required</div>
                                <?php } ?>

                                
                            </div>
                            <div class="content">
                            	<div class="row">
                                	<div class="col-md-12">
                                    	<div class="form-group">
		                                  	<label class="col-md-2 control-label">Author</label>
		                                    <div class="col-md-6">
		                                    	<input type="hidden" class="form-control" name="id" value="<?=$row->id?>" />
		                                    	<input type="text" class="form-control" name="author" value="<?=$row->nama?>" />
		                                    </div>
		                                </div>
		                                <div class="form-group">
		                                	<label class="col-md-2 control-label">Barcode</label>
		                                    <div class="col-md-6">
		                                    	<input type="text" class="form-control" name="barcode" value="<?=$row->barcode?>" />
		                                    </div>
		                            	</div>
		                                <div class="form-group">
		                               		<label class="col-md-2 control-label">Text</label>
		                                 	<div class="col-md-6">
		                                   		<textarea class="form-control" name="review" rows="5"><?=$row->isireview?></textarea>
		                                 	</div>
		                             	</div>
		                              	<div class="form-group">
		                              		<label class="col-md-2 control-label">Rating</label>
		                                	<div class="col-md-6">
												Bad&nbsp;
<input type="radio" name="rating" value="1" id="rating" <?php if($row->rating=="1") {echo "checked";}?>  />
												&nbsp;
												<input type="radio" name="rating" value="2" id="rating" <?php if($row->rating=="2") {echo "checked";}?>/>
												&nbsp;
												<input type="radio" name="rating" value="3" id="rating" <?php if($row->rating=="3") {echo "checked";}?>/>
												&nbsp;
												<input type="radio" name="rating" value="4" id="rating" <?php if($row->rating=="4") {echo "checked";}?>/>
												&nbsp;
												<input type="radio" name="rating" value="5" id="rating" <?php if($row->rating=="5") {echo "checked";}?>/>
												&nbsp;Good
											</div>
		                                </div>
		                                <div class="form-group">
		                                	<label class="col-md-2 control-label">Approved</label>
		                                 	<div class="col-md-6">
		                                 		<select name="approved" class="form-control">
		                                        	<option <?php if($row->approved == 'Yes'){ echo 'selected';}?>>Yes</option>
		                                        	<option <?php if($row->approved == 'No'){ echo 'selected';}?>>No</option>
		                                   		</select>
		                              		</div>
		                              		
		                             	</div>
		                             	<div class="form-group">
		                             		<div class="col-md-12">
		                             			<button type="submit" class="btn btn-success pull-right" value="save"><i class="fa fa-floppy-o"></i> Save Review</button>
		                             		</div>
		                             	</div>
                                    </div>
                                </div>
							</div>
							<?php } ?>
							</form>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <?php $this->load->view('adminpage/footer')?>

    </div>
</div>


</body>
    <!--   Core JS Files and PerfectScrollbar library inside jquery.ui   -->
    <script src="<?=base_url()?>assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/bootstrap.min.js" type="text/javascript"></script>


	<!--  Forms Validations Plugin -->
	<script src="../assets/js/jquery.validate.min.js"></script>

	<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
	<script src="../assets/js/moment.min.js"></script>

    <!--  Date Time Picker Plugin is included in this js file -->
    <script src="../assets/js/bootstrap-datetimepicker.js"></script>

    <!--  Select Picker Plugin -->
    <script src="../assets/js/bootstrap-selectpicker.js"></script>

	<!--  Checkbox, Radio, Switch and Tags Input Plugins -->
	<script src="<?=base_url()?>assets/js/bootstrap-checkbox-radio-switch-tags.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Sweet Alert 2 plugin -->
	<script src="../assets/js/sweetalert2.js"></script>

    <!-- Vector Map plugin -->
	<script src="../assets/js/jquery-jvectormap.js"></script>

    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Wizard Plugin    -->
    <script src="../assets/js/jquery.bootstrap.wizard.min.js"></script>

    <!--  Datatable Plugin    -->
    <script src="../assets/js/bootstrap-table.js"></script>

    <!--  Full Calendar Plugin    -->
    <script src="../assets/js/fullcalendar.min.js"></script>

    <!-- Light Bootstrap Dashboard Core javascript and methods -->
	<script src="<?=base_url()?>assets/js/light-bootstrap-dashboard.js"></script>

	<!--   Sharrre Library    -->
    <script src="../assets/js/jquery.sharrre.js"></script>

	<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	

</html>
