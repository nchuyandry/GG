<div class="sidebar" data-color="black" data-image="<?=base_url()?>assets/img/bg.jpg">

        <div class="logo">
            <a href="<?=base_url().'admin'?>" class="logo-text">
                Administrator Page
            </a>
        </div>

    	<div class="sidebar-wrapper">
            <div class="user">
                <div class="photo">
                    <img src="<?=base_url()?>assets/img/default-avatar.png" />
                </div>
                <div class="info">
                    <a data-toggle="collapse" href="#collapseExample" class="collapsed">
                        <?=$this->session->userdata('username')?>
                        <b class="caret"></b>
                    </a>
                    <div class="collapse" id="collapseExample">
                        <ul class="nav">
                            <li><a href="<?=base_url().'admin/useradmin'?>">User Admin</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <ul class="nav">
                <li class="<?=($this->uri->segment(2)===NULL)?'active':''?>"  >
                    <a href="<?=base_url().'admin'?>">
                        <i class="fa fa-dashboard"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li >
                    <a data-toggle="collapse" href="#catalog">
                        <i class="fa fa-database"></i>
                        <p>Main Data
                           <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse" id="catalog">
                        <ul class="nav">
                            <li class="<?=($this->uri->segment(2)==='products')?'active':''?>" >
                            	<a href="<?=base_url().'admin/products'?>">Products</a>
                            </li>
                            <li class="<?=($this->uri->segment(2)==='categories')?'active':''?>" >
                            	<a href="<?=base_url().'admin/categories'?>">Categories</a>
                            </li>
                            <li class="<?=($this->uri->segment(2)==='reviews')?'active':''?>" >
                            	<a href="<?=base_url().'admin/reviews'?>">Reviews</a>
                            </li>
                            <li class="<?=($this->uri->segment(2)==='testimonial')?'active':''?>" >
                            	<a href="<?=base_url().'admin/testimonial'?>">Testimonial</a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="<?=($this->uri->segment(2)==='invoices')?'active':''?>" >
                    <a data-toggle="collapse" href="#sales">
                        <i class="fa fa-shopping-bag"></i>
                        <p>Sales
                           <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse" id="sales">
                        <ul class="nav">
                            <li><a href="<?=base_url().'admin/invoices'?>">Invoices</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <a data-toggle="collapse" href="#setting">
                        <i class="fa fa-cog"></i>
                        <p>Setting
                           <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse" id="setting">
                        <ul class="nav">
                            <li class="<?=($this->uri->segment(2)==='setting')?'active':''?>" >
                            	<a href="<?=base_url().'admin/setting'?>">Page Setting</a>
                            </li>
                            <li class="<?=($this->uri->segment(2)==='banner')?'active':''?>" >
                            	<a href="<?=base_url().'admin/banner'?>">Banner Setting</a>
                            </li>
                        </ul>
                    </div>
                </li>
            </ul>
    	</div>
    </div>