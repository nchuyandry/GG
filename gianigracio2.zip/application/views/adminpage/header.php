<nav class="navbar navbar-default">
    		<div class="container-fluid">
    			<div class="navbar-header">
    				<button type="button" class="navbar-toggle" data-toggle="collapse">
    					<span class="sr-only">Toggle navigation</span>
    					<span class="icon-bar"></span>
    					<span class="icon-bar"></span>
    					<span class="icon-bar"></span>
    				</button>
    				<a class="navbar-brand" href="#"><?=$title?></a>
    			</div>
    			<div class="collapse navbar-collapse">

    				<form class="navbar-form navbar-left navbar-search-form" role="search">
    					<div class="input-group">
    						<span class="input-group-addon"><i class="fa fa-search"></i></span>
    						<input type="text" value="" class="form-control" placeholder="Search...">
    					</div>
    				</form>

    				<ul class="nav navbar-nav navbar-right">
    					<li class="dropdown">
    						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
    							<i class="fa fa-gavel"></i>
    							<p class="hidden-md hidden-lg">
    								Actions
    								<b class="caret"></b>
    							</p>
    						</a>
    						<ul class="dropdown-menu">
    							<li><a href="#">Create New Post</a></li>
    							<li><a href="#">Manage Something</a></li>
    							<li><a href="#">Do Nothing</a></li>
    							<li><a href="#">Submit to live</a></li>
    							<li class="divider"></li>
    							<li><a href="#">Another Action</a></li>
    						</ul>
    					</li>

    					<li class="dropdown">
    						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
    							<i class="fa fa-bell-o"></i>
    							<span class="notification">5</span>
    							<p class="hidden-md hidden-lg">
    								Notifications
    								<b class="caret"></b>
    							</p>
    						</a>
    						<ul class="dropdown-menu">
    							<li><a href="#">Notification 1</a></li>
    							<li><a href="#">Notification 2</a></li>
    							<li><a href="#">Notification 3</a></li>
    							<li><a href="#">Notification 4</a></li>
    							<li><a href="#">Another notification</a></li>
    						</ul>
    					</li>

    					<li class="dropdown dropdown-with-icons">
    						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
    							<i class="fa fa-list"></i>
    							<p class="hidden-md hidden-lg">
    								More
    								<b class="caret"></b>
    							</p>
    						</a>
    						<ul class="dropdown-menu dropdown-with-icons">
    							<li>
    								<a href="#">
    									<i class="fa fa-envelope-o"></i> Messages
    								</a>
    							</li>
    							<li>
    								<a href="<?=base_url().'admin/setting'?>">
    									<i class="fa fa-cog"></i> Settings
    								</a>
    							</li>
    							<li class="divider"></li>
    							<li>
    								<a href="<?=base_url().'logout'?>" class="text-danger">
    									<i class="fa fa-power-off"></i>
    									Log out
    								</a>
    							</li>
    						</ul>
    					</li>

    				</ul>
    			</div>
    		</div>
    	</nav>