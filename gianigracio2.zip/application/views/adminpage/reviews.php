
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Administrator Page | Giani Gracio Shop Online</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?=base_url()?>assets/dist/sweetalert.css" rel="stylesheet" />
	
    <!--  Light Bootstrap Dashboard core CSS    -->
    <link href="<?=base_url()?>assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>

	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
</head>
<body>

<div class="wrapper">
    <?php $this->load->view('adminpage/sidebar')?>

    <div class="main-panel">
        <?php 
        $data['title'] = 'Reviews';
        $this->load->view('adminpage/header' , $data);
        ?>

        <div class="content">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">
                        <div class="card ">
                        <form action="<?=base_url().'admin/deleteselreview'?>" class="form-horizontal" method="post">
                            <div class="header">
                                <h4 class="title">Reviews
                                	<button type="submit" class="btn btn-danger pull-right btn-xs" value="Delete" onclick="return confirm('Are you sure want to delete this data?')"><i class="fa fa-trash"></i> 
                            	Delete Selected</button>
                                </h4>

                                <?=$this->session->flashdata('pesan')?>
                            </div>
                            <div class="content">
                                <div class="row">
                                    <div class="col-md-12">
                                    	<div class="table-responsive">
                                    	<table class="table table-striped table-hover">
                                    		<thead>
                                    			<tr>
                                    				<th><input type="checkbox" id="select-all" /></th>
                                    				<th>Barcode</th>
                                    				<th>Date Added</th>
                                    				<th>Author</th>
                                    				<th>Rating</th>
                                    				<th>Approved</th>
                                    				<th>Action</th>
                                    			</tr>
                                    		</thead>
                                    		<tbody>
                                    			<?php foreach($reviews as $row){?>
                                    			<tr>
                                    				<td><input type="checkbox" name="del[]" value="<?=$row->id?>"></td>
                                    				<td><?=$row->barcode?></td>
                                    				<td><?=$row->tgl?></td>
                                    				<td><?=$row->nama?></td>
                                    				<td>
                                    					<?php for($i = 0; $i < $row->rating; $i++){ ?>
					                        				<i class="fa fa-star"></i>
					                    				<?php } ?>
									                    <?php if($row->rating == '1'){?>
									                    	<i class="fa fa-star-o"></i>
									                    	<i class="fa fa-star-o"></i>
									                    	<i class="fa fa-star-o"></i>
									                    	<i class="fa fa-star-o"></i>
									                    <?php }elseif($row->rating == '2'){?>
									                    	<i class="fa fa-star-o"></i>
									                    	<i class="fa fa-star-o"></i>
									                    	<i class="fa fa-star-o"></i>
									                    <?php }elseif($row->rating == '3'){?>
									                    	<i class="fa fa-star-o"></i>
									                    	<i class="fa fa-star-o"></i>
									                    <?php }elseif($row->rating == '4'){?>
									                    	<i class="fa fa-star-o"></i>
									                    <?php } ?>
                                    				</td>
                                    				<td><?=$row->approved?></td>
                                    				<td>
                                    					<a href="<?=base_url().'admin/editreview/'.$row->id?>" class="btn btn-warning btn-xs" title="Edit" ><i class="fa fa-pencil-square-o"></i></a>
                                    					<a href="<?=base_url().'admin/deleterev/'.$row->id?>" class="btn btn-danger btn-xs" title="Delete"><i class="fa fa-trash" onclick="return confirm('Are you sure want to delete this data?')"></i></a>
                                    					
                                    				</td>
                                    			</tr>
                                    			<?php } ?>
                                    		</tbody>
                                    	</table>
										</div>
                                    </div>
                                </div>
                            </div> <!--content-->
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <?php $this->load->view('adminpage/footer')?>

    </div>
</div>


</body>
    <!--   Core JS Files and PerfectScrollbar library inside jquery.ui   -->
    <script src="<?=base_url()?>assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/dist/sweetalert.min.js" type="text/javascript"></script>
	<script>
		$(document).ready(function(){   
       		$('#select-all').on('click', function(){
       			if(this.checked){
					$(':checkbox').each(function(){
						this.checked = true;
					});
				}else {
					$(':checkbox').each(function() {
						this.checked = false;
					});
				}
       		});
    	});
	</script>

	<!--  Forms Validations Plugin -->
	<script src="../assets/js/jquery.validate.min.js"></script>

	<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
	<script src="../assets/js/moment.min.js"></script>

    <!--  Date Time Picker Plugin is included in this js file -->
    <script src="../assets/js/bootstrap-datetimepicker.js"></script>

    <!--  Select Picker Plugin -->
    <script src="../assets/js/bootstrap-selectpicker.js"></script>

	<!--  Checkbox, Radio, Switch and Tags Input Plugins -->
	<script src="../assets/js/bootstrap-checkbox-radio-switch-tags.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Sweet Alert 2 plugin -->
	<script src="../assets/js/sweetalert2.js"></script>

    <!-- Vector Map plugin -->
	<script src="../assets/js/jquery-jvectormap.js"></script>

    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Wizard Plugin    -->
    <script src="../assets/js/jquery.bootstrap.wizard.min.js"></script>

    <!--  Datatable Plugin    -->
    <script src="../assets/js/bootstrap-table.js"></script>

    <!--  Full Calendar Plugin    -->
    <script src="../assets/js/fullcalendar.min.js"></script>

    <!-- Light Bootstrap Dashboard Core javascript and methods -->
	<script src="<?=base_url()?>assets/js/light-bootstrap-dashboard.js"></script>

	<!--   Sharrre Library    -->
    <script src="../assets/js/jquery.sharrre.js"></script>

	<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	<script>
		$(document).ready(function(){
		    $('[data-toggle="tooltip"]').tooltip(); 
		});
	</script>

</html>
