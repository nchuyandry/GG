
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Administrator Page | Giani Gracio Shop Online</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
	
    <!--  Light Bootstrap Dashboard core CSS    -->
    <link href="<?=base_url()?>assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>


	
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
</head>
<body>

<div class="wrapper">
    <?php $this->load->view('adminpage/sidebar')?>

    <div class="main-panel">
        <?php 
        $data['title'] = 'Dashboard';
        $this->load->view('adminpage/header', $data);
        ?>

        <div class="content">
            <div class="container-fluid">
            	<form id="prod" enctype="multipart/form-data" action="<?=base_url().'admin/updateproduct'?>" method="POST" class="form-horizontal" >
            <?php foreach($editp as $row){?>	
                <div class="row">
                    <div class="col-md-12">
                        <div class="card ">
                            <div class="header">
                                <h4 class="title">Edit Product <button type="submit" class="btn btn-success pull-right" value="save"><i class="fa fa-floppy-o"></i> Update Product</button></h4>
                                <!--<p class="category"></p>-->

                            </div>
                            <div class="content">
                            	<ul role="tablist" class="nav nav-tabs">
                                    <li role="presentation" class="active">
                                        <a href="#general" data-toggle="tab">General Data</a>
                                    </li>
                                    <li>
                                        <a href="#option" data-toggle="tab">Option</a>
                                    </li> 
                                    <li>
                                        <a href="#image" data-toggle="tab">Image</a>
                                    </li>                                   
                                </ul>
                                <div class="tab-content">
                                    <div id="general" class="tab-pane active">
<div class="row">
	<div class="col-md-6">
		<div class="form-group">
			<label class="col-md-4 control-label">Date Input</label>
		    	<div class="col-md-8">
		    		<input type="datetime" class="form-control" name="tgl" value="<?=$row->tgl?>" />
		         	<input type="hidden" class="form-control" name="id" value="<?=$row->idproduk?>" />
		    	</div>
		</div>
		<div class="form-group">
			<label class="col-md-4 control-label">Barcode</label>
				<div class="col-md-8">
			   		<input type="text" class="form-control" name="barcode" value="<?=$row->barcode?>"/>
			 	</div>
		</div>
		<div class="form-group">
			<label class="col-md-4 control-label">Product Name</label>
				<div class="col-md-8">
			    	<input type="text"  class="form-control" name="nama" value="<?=$row->nama?>" />
				</div>
		</div>
		<div class="form-group">
			<label class="col-md-4 control-label">Description</label>
				<div class="col-md-8">
			    	<textarea class="form-control" name="deskripsi"><?=$row->deskripsi?></textarea>
			  	</div>
		</div>
		<div class="form-group">
			<label class="col-md-4 control-label">Tag Keywords</label>
				<div class="col-md-8">
			    	<input name="tagsinput" class="tagsinput tag-azure form-control" value="<?=$row->tag?>" />
			 	</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="form-group">
			<label class="col-md-4 control-label">Category</label>
		 	<div class="col-md-8">
		    	<select class="form-control" name="kategori" onclick="getM()">
		        	<?php foreach($kat as $r){ ?>
					<option value="<?=$r->id ?>" <?php if($row->idkategori==$r->id){echo "selected='selected'";} ?> ><?=$r->namakat?></option>	
            		<?php } ?>
		      	</select>
		  	</div>
		</div>
		<div class="form-group">
			<label class="col-md-4 control-label">Model</label>
			<div class="col-md-8">
				<input type="text" name="model" class="form-control" value="<?=$row->model?>" id="model"/>
			</div>
		</div>
		<div class="form-group">
		    <label class="col-md-4 control-label">Status</label>
		    <div class="col-md-8">
		    	<select class="form-control" name="status">
		        	<option value="Enabled" <?php if($row->status=="Enabled"){echo "selected='selected'";} ?>>Enabled</option>
		           	<option value="Disabled" <?php if($row->status=="Disabled"){echo "selected='selected'";} ?>>Disabled</option>
		     	</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-4 control-label">Featured Product</label>
		 	<div class="col-md-8">
		    	<select class="form-control" name="featured">
		        	<option value="No" <?php if($row->featured=="No"){echo "selected='selected'";} ?>>No</option>
		         	<option value="Yes" <?php if($row->featured=="Yes"){echo "selected='selected'";} ?>>Yes</option>
		    	</select>
		  	</div>
		</div>
		<div class="form-group" id="img<?=$row->idproduk?>">
			<label class="col-md-4 control-label">Image</label>
			<div class="col-md-8">
				<img src="<?=base_url().'uploads/'.$row->image?>" width="80px"/>
<a href="javascript:void(0)" onclick="DeleteImg(<?=$row->idproduk;?>)"  title="Delete Image" class="btn  btn-danger pull-right">
				<i class="fa fa-trash"></i> Remove Image</a>
			</div>
		</div>	
	</div>
</div>
		                                    	
		                                        

                                    </div>
                                    <div id="option" class="tab-pane">
                                    	<h4 class="title"><a class="btn btn-info pull-right" onclick="add()" style="cursor:pointer;text-decoration:none;"><i class="fa fa-plus"></i> Add Option</a></h4>
                                    	<div class="row">
                                    		<div class="col-md-9 col-md-offset-1">
		                                    	<table class="table table-hover">
		                                    		<thead>
		                                    			<tr>
		                                    				<th>#</th>
		                                    				<th>Size</th>
		                                    				<th>Qty</th>
		                                    				<th>Price</th>
		                                    				<th>Action</th>
		                                    			</tr>
		                                    		</thead>
		                                    		<tbody>
		                                    		<?php 
		                                    		$no = 0;
		                                    		foreach($edits as $r){
		                                    			$no++;
		                                    			?>
		                                    			<tr id="size<?=$r->idsize;?>">
		                                    				<td><?=$no?></td>
		                                    				<td><?=$r->size?></td>
		                                    				<td><?=$r->qty?></td>
		                                    				<td><?=$r->price?></td>
		                                    				<td>
		                                    				<a href="javascript:void(0)" onclick="EditSize(<?=$r->idsize;?>)" class="btn btn-warning btn-sm btn-xs" title="Edit Size" ><i class="fa fa-pencil-square-o"></i></a>
		                                    				<a href="javascript:void(0)" onclick="DeleteSize(<?=$r->idsize;?>)"  title="Delete Size" class="btn btn-sm btn-xs btn-danger"><i class="fa fa-trash"></i></a>
		                                    				</td>
		                                    			</tr>
		                                    		<?php } ?>
		                                    		</tbody>
		                                    	</table>
                                    		</div>
                                    	</div>
                                    	<br />
                                    	<div class="form-group">
                                    		<label class="col-md-2 control-label">Product Size</label>
                                    		<div class="col-md-4">
                                    			<input type="text" class="form-control" name="size[]" />
                                    		</div>
                                    	</div>
                                    	<div class="form-group">
                                    		<label class="col-md-2 control-label">Quantity</label>
                                    			<div class="col-md-4">
                                    				<input type="number" class="form-control" name="qty[]" />
                                    			</div>
                                    	</div>
                                    	<div class="form-group">
                                    		<label class="col-md-2 control-label">Price</label>
                                    			<div class="col-md-4">
                                    				<input type="number" class="form-control" name="price[]" /></div>
                                    			</div>
                            			</div>
 </form>
									<div id="image" class="tab-pane">
										<h4 class="title" style="padding-bottom: 20px"><a class="btn btn-info pull-right" onclick="addimg()" style="cursor:pointer;text-decoration:none;"><i class="fa fa-plus"></i> Add Image</a></h4>
										
										<?php foreach($editimg as $img){?>
										<div class="form-group" id="img<?=$img->id?>">
			                            	<label class="col-md-2 control-label">Image</label>
			                                	<div class="col-md-4">
			                                   		<img  src="<?=base_url().'uploads/'.$img->image?>" width="80px"/>
			                                   	</div>
			                                   	<div class="col-md-4">
			                                   		<a href="javascript:void(0)" onclick="DeleteImage(<?=$img->id;?>)"  title="Delete Image" class="btn  btn-danger"><i class="fa fa-trash"></i></a>
			                                   	</div>
			                        	</div>
			                        	<?php } ?>
<form enctype="multipart/form-data" action="<?=base_url().'admin/updateimg'?>" method="POST" class="form-horizontal" >
			                        	<div class="form-group">
											<label class="col-md-2 control-label">Image</label>
											<div class="col-md-4">
												<input type="hidden" class="form-control" name="barcode" value="<?=$row->barcode?>"/>
												<input type="file" class="form-control" name="img[]" />
											</div>
											<button type="submit" class="btn btn-primary" value="Update"><i class="fa fa-floppy-o"></i> Update</button>
										</div>
</form>
									</div>
								</div>
                            </div>
                        </div>
                    </div>
                </div>
	<?php } ?>
           
            </div>
        </div>


        <?php $this->load->view('adminpage/footer')?>

    </div>
</div>


</body>
    <!--   Core JS Files and PerfectScrollbar library inside jquery.ui   -->
    <script src="<?=base_url()?>assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>assets/js/bootstrap.min.js" type="text/javascript"></script>


	<!--  Forms Validations Plugin -->
	<script src="../assets/js/jquery.validate.min.js"></script>

	<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
	<script src="../assets/js/moment.min.js"></script>

    <!--  Date Time Picker Plugin is included in this js file -->
    <script src="../assets/js/bootstrap-datetimepicker.js"></script>

    <!--  Select Picker Plugin -->
    <script src="../assets/js/bootstrap-selectpicker.js"></script>

	<!--  Checkbox, Radio, Switch and Tags Input Plugins -->
	<script src="<?=base_url()?>assets/js/bootstrap-checkbox-radio-switch-tags.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!-- Sweet Alert 2 plugin -->
	<script src="../assets/js/sweetalert2.js"></script>

    <!-- Vector Map plugin -->
	<script src="../assets/js/jquery-jvectormap.js"></script>

    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Wizard Plugin    -->
    <script src="../assets/js/jquery.bootstrap.wizard.min.js"></script>

    <!--  Datatable Plugin    -->
    <script src="../assets/js/bootstrap-table.js"></script>

    <!--  Full Calendar Plugin    -->
    <script src="../assets/js/fullcalendar.min.js"></script>

    <!-- Light Bootstrap Dashboard Core javascript and methods -->
	<script src="<?=base_url()?>assets/js/light-bootstrap-dashboard.js"></script>

	<!--   Sharrre Library    -->
    <script src="../assets/js/jquery.sharrre.js"></script>

	<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	<script>
		function add(){
			$("#option").append('<hr /><div class="form-group"><label class="col-md-2 control-label">Product Size</label><div class="col-md-4"><input type="text" class="form-control" name="size[]" /></div></div><div class="form-group"><label class="col-md-2 control-label">Quantity</label><div class="col-md-4"><input type="number" class="form-control" name="qty[]" /></div></div><div class="form-group"><label class="col-md-2 control-label">Price</label><div class="col-md-4"><input type="number" class="form-control" name="price[]" /></div></div><hr/>').children(':last');
		}
		function addimg(){
			$("#image").append('<div class="form-group"><label class="col-md-2 control-label">Image</label><div class="col-md-4"><input type="file" class="form-control" name="img[]" /></div></div>').children(':last');
		}
	</script>
	<script type="text/javascript">
	function getM(){
		var value = $("select[name='kategori'] option:selected").text();
		$('#model').val(value);
	}
	function DeleteImage(id)
    {
        if (confirm("Are you sure!") == true) {
        var id = id;
        $('#hide'+id).show();
        $.ajax({
            url:"<?php echo base_url('admin/Deleteimg');?>/"+id,
            success:function(data)
            {
            	$('#img'+id).hide();            	
            }
            });
        }
    }
    function DeleteImg(id)
    {
        if (confirm("Are you sure!") == true) {
        var id = id;
        $('#hide'+id).show();
        $.ajax({
            url:"<?php echo base_url('admin/Deleteimg');?>/"+id,
            success:function(data)
            {
            	$('#img'+id).hide();            	
            }
            });
        }
    }
    function DeleteSize(id)
    {
        if (confirm("Are you sure!") == true) {
        var id = id;
        $('#hide'+id).show();
        $.ajax({
            url:"<?php echo base_url('admin/deletesize');?>/"+id,
            success:function(data)
            {
            	$('#size'+id).hide();            	
            }
            });
        }
    }
    function EditSize(id)
    {
        var id = id;
        $('#hide'+id).show();
        $.ajax({
            url:"<?php echo base_url('admin/EditSize');?>/"+id,
            success:function(data)
            {          
            	
	            $('#size'+id).html(data);
//	            $('.hide').hide(); 
            }      
        });
    }
    function UpdateSize(id)
    {
        var id = id;
        alert(id);
         var data = $("#frmsize"+id).serialize();
        alert(data);
        $.ajax({
        	type:"POST",
          	url:"<?php echo base_url('admin/UpdateSize');?>/"+id,
           	data:data,
          	success:function(data)
            	{
                	console.log(data);
                   	if(data == "false"){
                    	alert("size name already in use");
                   	}else{
//                       	alert(data);
						
                      	$('.updatedData'+id).html(data);
                     	location.reload();
                   	}
            	}
        });
    }
    function Cancel()
    {
        Location.reload();
    }
	</script>
</html>
