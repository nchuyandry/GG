<!-- Header Section Starts -->
<style>
	.dropdown-menu>li>a {
	    display: block;
	    padding: 3px 20px;
	}

</style>
	<header id="header-area">
	<!-- Nested Container Starts -->
		<div class="container">
		<!-- Nested Row Starts -->
			<div class="row">
			<!-- Logo Starts -->
				<div class="col-sm-3 col-xs-12">
					<a href="<?=base_url()?>"><img src="<?=base_url()?>assets/img/logoG.png" title="Giani Gracio" alt="Giani Gracio" class="img-responsive img-center-xs logo" /></a>
				</div>
			<!-- Logo Ends -->
			<!-- Header Right Col Starts -->
				<div class="col-lg-7 col-sm-8 col-xs-12 col-lg-offset-1 col-sm-offset-1 header-top">
				<!-- Nested Row Starts -->
					<div class="row">
					<!-- Header Links Starts -->
						<div class="col-sm-7 col-xs-12">
							<div class="header-links">
								<ul class="nav navbar-nav pull-right">
									<li>
										<a href="<?=base_url()?>">
											<i class="fa fa-home hidden-lg hidden-md" title="Home"></i>
											<span class="hidden-sm hidden-xs">
												Home
											</span>
										</a>
									</li>
									<li>
										<a href="#">	
											<i class="fa fa-heart hidden-lg hidden-md" title="Wish List"></i>
											<span class="hidden-sm hidden-xs">
												Wish List(0)
											</span>
										</a>
									</li>
									<li>
										<a href="<?=base_url().'viewcart'?>">
											<i class="fa fa-shopping-cart hidden-lg hidden-md" title="Shopping Cart"></i>
											<span class="hidden-sm hidden-xs">
												Shopping Cart
											</span>
										</a>
									</li>
									<?php if($this->session->userdata('email')){?>
									<li>
										<a href="<?=base_url().''?>" class="dropdown-toggle" data-toggle="dropdown">
											<i class="fa fa-user hidden-lg hidden-md" title="My Account"></i>
											<span class="hidden-sm hidden-xs">
												My Account <i class="fa fa-caret-down"></i>
											</span>
										</a>
										<ul class="dropdown-menu">
											<li>
												<a href="<?=base_url().'history'?>">My Order</a>
											</li>
											<li style="padding-left: 0">
												<a href="<?=base_url().'sign-out'?>">Log Out</a>
											</li>
										</ul>
									</li>
									

									
									<?php }else{?>
									<li>
										<a href="<?=base_url().'register'?>">
											<i class="fa fa-unlock hidden-lg hidden-md" title="Register"></i>
											<span class="hidden-sm hidden-xs">
												Register
											</span>
										</a>
									</li>
									<li>
										<a href="<?=base_url().'sign-in'?>">
											<i class="fa fa-lock hidden-lg hidden-md" title="Login"></i>
											<span class="hidden-sm hidden-xs">
												Login
											</span>
										</a>
									</li>
									<?php } ?>
								</ul>
							</div>
						</div>
					<!-- Header Links Ends -->

					<!-- Search Starts -->
						<div class="col-sm-7 col-xs-12">
						<form action="<?=base_url().'search-result'?>" method="GET" >
							<div id="search">
								<div class="input-group">
								  <input type="text" name="search" class="form-control input-lg" placeholder="Search" required>
								  <span class="input-group-btn">
									<button class="btn btn-lg" type="submit">
										<i class="fa fa-search"></i>
									</button>
								  </span>
								</div>
							</div>
						</form>
						</div>
					<!-- Search Ends -->
					<!-- Shopping Cart Starts -->
						<div class="col-sm-5 col-xs-12">
							<div id="cart" class="btn-group btn-block pull-right">
								<button type="button" data-toggle="dropdown" class="btn btn-block btn-lg dropdown-toggle">
									<i class="fa fa-shopping-cart"></i>
									<span class="hidden-md hidden-sm">Cart:</span> 
									<span id="cart-total"><?=$this->cart->total_items()?> Items</span>
									<i class="fa fa-caret-down"></i>
								</button>
								<ul class="dropdown-menu pull-right">
								<?php 
									$i = 0;
									foreach($this->cart->contents()as $item):
									$i++; 
								?>
									<li>
										<table class="table hcart">
											<tr>
												<td class="text-center">
													<a href="<?=base_url().'detail-product/'.$item['barcode']?>">
														<img src="<?=base_url().'uploads/'.$item['image']?>" alt="image" title="image" class="img-responsive" />
													</a>
												</td>
												<td class="text-left">
													<a href="<?=base_url().'detail-product/'.$item['barcode']?>">
														<?=$item['barcode']?>
													</a>
												</td>
												<td class="text-right"><?=$item['qty']?></td>
												<td class="text-right">Rp.<?=number_format($item['price'],0,',','.')?>,-</td>
												<td class="text-center">
													<a href="<?=base_url().'home/deleteitem/'.$item['rowid']?>">
														<i class="fa fa-times"></i>
													</a>
												</td>
											</tr>
											
										</table>
									</li>
								<?php endforeach; ?>
									<li>
										<table class="table table-bordered total">
											<tbody>
											<?php if($this->cart->total_items()!= 0){?>									
												<tr>
													<td>&nbsp; &nbsp;</td>
													<td class="text-right"><strong>Sub-Total</strong></td>
													<td class="text-left">Rp. <?=number_format($this->cart->total(),0,',','.')?>,-</td>
												</tr>
												<tr>
													<td>&nbsp; &nbsp;</td>
													<td class="text-right"><strong>Disc (-25%)</strong></td>
													<?php
													$y = $this->cart->total();
													$tot = $y * 0.25;
													$totall = $y - $tot;
													?>
													<td class="text-left">Rp. <?=number_format($tot,0,',','.')?>,-</td>
												</tr>

												<tr>
													<td>&nbsp; &nbsp;</td>
													<td class="text-right"><strong>Total</strong></td>
													<td class="text-left">Rp. <?=number_format($totall,0,',','.')?>,-</td>
												</tr>
											<?php }else{?>
												<tr>
													<td><p class="text-center">Cart is Empty</p></td>
												</tr>
											<?php } ?>
											</tbody>
										</table>
									</li>
									<li>
									<?php if($this->cart->total_items()== 0){?>	
										<p></p>
									<?php }else{ ?>
										<p class="text-right btn-block1">
											<a href="<?=base_url().'viewcart'?>">
												View Cart
											</a>
<?php
$name = $this->session->userdata('email');
$nama = $this->modeldb->checkcus($name);
?>
											<a href="<?=base_url().'order-review/'.$nama?>">
												Checkout
											</a>
										</p>
									<?php } ?>
									</li>									
								</ul>
							</div>
						</div>
					<!-- Shopping Cart Ends -->
					</div>
				<!-- Nested Row Ends -->
				</div>
			<!-- Header Right Col Ends -->
			</div>
		<!-- Nested Row Ends -->		
		</div>
	<!-- Nested Container Ends -->
	</header>
<!-- Header Section Ends -->