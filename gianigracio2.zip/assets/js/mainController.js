var app=angular.module('bigmoney',[]);
app.controller('kontrol',function($scope,$http){
    $scope.products=[];
    $http.get("<?php echo base_url('home/viewdata');?>").success(function(result){
     $scope.products=result;
    });
    
   });